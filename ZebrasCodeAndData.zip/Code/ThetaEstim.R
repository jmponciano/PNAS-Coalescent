# Great!  It works beautifully.  For example, for the locus pX02, below
# under the MLE column are the inter-allelic mutation rates and the 
# scaled mutation rate (2N*mu), where mu is the prob. of mutation per
# generation.

# I will compute the same for every locus.  With the estimates of theta,
# I can run an MCMC to estimate the mean time to the most recent common
# ancestor starting with the frequency counts from the mutation
# experiments and projecting back in the past.  I still need to check 
# carefully how these numbers will translate to actual generations, that
# shouldn’t be too hard.  We’ll see…  Full analysis to follow soon!

library(MCMCpack)
library(MASS)
library(VGAM) 
library(dirmult) 

tmp <- read.delim("ZebraSNR.txt")
head(tmp) # just checking variable names
tags<-names(tmp[-c(1,2)]) # loci tag names
counts.list	<-	list()

for(i in 1:length(tags)){
	ith.tag	<-	which(names(tmp)==tags[i])
	counts.list[[i]]<-as.matrix(table(tmp$zebnum,tmp[,ith.tag])[,-1]) # remove the first col of -9's 
}
names(counts.list)<-tags # now counts.list is a list, per locus, of the number of times each one of its
						 # alleles was recorded in each zebra

trial <- dirmult(counts.list$pX02, epsilon=10^(-4), trace=FALSE)
dirmult.summary(counts.list$pX02,trial)

###  OK, now for real: first, separating non-segregating alleles from the rest:
###  The outcome is a data set that has the allele frequency counts for every
###  segregating loci
segreg.alleles <- rep(0,length(tags))

for(i in 1:length(tags)){
	nalleles <- ncol(counts.list[[i]])
	print(nalleles)
	if(nalleles>1){segreg.alleles[i] <- 1} 
}

segreg.indices <- (1:length(tags))[segreg.alleles==1]

all.segreg.counts <- list()
for(i in 1:length(segreg.indices)){
	all.segreg.counts[[i]] <- counts.list[[segreg.indices[i]]]
	print(ncol(all.segreg.counts[[i]]))	
}

names(all.segreg.counts) <- tags[segreg.indices]

# List with frequency counts for all segregating alleles:
all.segreg.counts




# Getting the matrix with haplotypes in the rows and a vector of frequency counts for each haplotype
# For the data that comes from the zebras.
# First we have to eliminate any row with a '-9', then identify all the different haplotypes and count them:
nobs <- nrow(tmp)
miss.dat <- rep(0,nobs)
for(i in 1:nobs){
	miss.dat[i] <- sum(tmp[i,]==-9)>0
}
nomiss.data  <- tmp[-which(miss.dat==1,arr.ind=TRUE),]
only.zebras  <- nomiss.data[nomiss.data[,2]!=111,]
only.labcult <- nomiss.data[nomiss.data[,2]==111,] 

nis.pzebra


