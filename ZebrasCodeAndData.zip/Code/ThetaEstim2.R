# Great!  It works beautifully.  For example, for the locus pX02, below
# under the MLE column are the inter-allelic mutation rates and the 
# scaled mutation rate (2N*mu), where mu is the prob. of mutation per
# generation.

# I will compute the same for every locus.  With the estimates of theta,
# I can run an MCMC to estimate the mean time to the most recent common
# ancestor starting with the frequency counts from the mutation
# experiments and projecting back in the past.  I still need to check 
# carefully how these numbers will translate to actual generations, that
# shouldn’t be too hard.  We’ll see…  Full analysis to follow soon!

library(MCMCpack)
library(MASS)
library(VGAM) 
library(dirmult) 

tmp <- read.delim("ZebraSNR.txt")
head(tmp) # just checking variable names
tags<-names(tmp[-c(1,2)]) # loci tag names
counts.list	<-	list()

for(i in 1:length(tags)){
	ith.tag	<-	which(names(tmp)==tags[i])
	counts.list[[i]]<-as.matrix(table(tmp$zebnum,tmp[,ith.tag])[,-1]) # remove the first col of -9's 
}
names(counts.list)<-tags # now counts.list is a list, per locus, of the number of times each one of its
						 # alleles was recorded in each zebra

trial <- dirmult(counts.list$pX02, epsilon=10^(-4), trace=FALSE)
dirmult.summary(counts.list$pX02,trial)

###  OK, now for real: first, separating non-segregating alleles from the rest:
###  The outcome is a data set that has the allele frequency counts for every
###  segregating loci
segreg.alleles <- rep(0,length(tags))

for(i in 1:length(tags)){
	nalleles <- ncol(counts.list[[i]])
	print(nalleles)
	if(nalleles>1){segreg.alleles[i] <- 1} 
}

segreg.indices <- (1:length(tags))[segreg.alleles==1]

all.segreg.counts <- list()
for(i in 1:length(segreg.indices)){
	all.segreg.counts[[i]] <- counts.list[[segreg.indices[i]]]
	print(ncol(all.segreg.counts[[i]]))	
}

names(all.segreg.counts) <- tags[segreg.indices]

# List with frequency counts for all segregating alleles:
all.segreg.counts
nsegreg <- length(all.segreg.counts)


# Estimating the scaled mutation rate per locus:
mutation.summaries <- list()
mutation.allmles <- list()
only.zebrasdat <- list()
nalleles <- rep(0,nsegreg)
all.theta.hats  <- matrix(rep(0,nsegreg),nrow=nsegreg,ncol=1)
dirmult.theta.hats <- all.theta.hats
for(i in 1:nsegreg){
	
	where.111 <- which(row.names(all.segreg.counts[[i]])=="111",arr.ind=TRUE)
	zebras.data <- all.segreg.counts[[i]][-where.111,]
	sum.cols <- apply(zebras.data,2,sum)
	which.0col <- which(sum.cols==0,arr.ind=TRUE)
	if(length(which.0col)>0){
		zebras.data <- zebras.data[,-which.0col]
	}
	only.zebrasdat[[i]] <- zebras.data
	nalleles[i] <- ncol(zebras.data)
	zebrasmles <- dirmult(zebras.data, epsilon=10^(-4), trace=FALSE)
	mutation.allmles[[i]] <- zebrasmles 
	mutation.summaries[[i]] <- dirmult.summary(zebras.data,zebrasmles)
	all.theta.hats[i] <- (1-zebrasmles$theta)/zebrasmles$theta
	dirmult.theta.hats[i] <- zebrasmles$theta
}
names(mutation.summaries) <- tags[segreg.indices]
names(mutation.allmles) <- tags[segreg.indices]
names(only.zebrasdat) <- tags[segreg.indices]
names(dirmult.theta.hats) <- tags[segreg.indices]
row.names(all.theta.hats) <- tags[segreg.indices]

# It seems that loci with only two alleles yield a gigantic theta estimate (comes from dirmult 
# having numerical issues).  To explore alternatives, I compare the estimates of theta of loci 
# with two alleles vs. loci with more than two alleles
cbind(all.theta.hats,nalleles)

# Computing the moments estimator of theta for all these data sets and printing it
moments.calc <- function(countsmat){
	
	K         <- dim(countsmat)[1];
	nreps     <- dim(countsmat)[2];
	nvec      <- apply(countsmat,2,sum);
	nmat      <- matrix(rep(nvec, each=K), nrow=K,ncol=nreps);
	phats     <- countsmat/nmat;
	
	N         <- sum(nvec);	
	alphas    <- (1/N)*apply(countsmat,1,sum);
	C.mat     <- matrix(0,nrow=K,ncol=nreps);
	
	for(i in 1:K){
		
		alpha.i <- alphas[i];
		for(s in 1:nreps){
			
			C.mat[i,s] <- (1/alpha.i)*nvec[s]*(phats[i,s]-alpha.i)^2
			
			}
		
		} 
	
	C.hat <- (((nreps-1)*(K-1))^(-1))*sum(C.mat);
	if(C.hat<1){C.hat<-1.000001};
	if(C.hat>nvec[1]){C.hat<-nvec[1]}
	g.hat <- (nvec[1]-C.hat)/(C.hat-1);
	
	
	return(list(alphas=alphas,C.hat=C.hat,g.hat=g.hat))
	
}

# I will us the MGLM estimate of theta. See comparisons here in this for loop 

library(MGLM)
theta.mom <- rep(0,nsegreg)

for(i in 1:nsegreg){
	
	zebracounts <- only.zebrasdat[[i]]
	theta.mom <- moments.calc(t(zebracounts))$g.hat
	print(only.zebrasdat[[i]])
	fit <- MGLMfit(data=zebracounts,dist="DM")
	print(sum(fit$estimate))
	print("my.theta, theta.mom, dirmult.theta, nalleles")
	print(c(all.theta.hats[i], theta.mom,dirmult.theta.hats[i], nalleles[i]))
}

save.image(file="ZebrasAnalysis.RData")

#  Before going on with that estimate of theta, I will:

# 1- use the tmp data and remove the data where zebnum==111 (the mutation experiment)
# 2- reduce it to all the segregating alleles data
# 3- remove the -9 allele numbers
# 4- figure out which is the most common allele per locus and make that a 0, the rest 1
# 5- figure out how many haplotypes there are, and how many indiviual observations per haplotype
# 6- Compute Tajima's D estimator of theta from there 
# 7- Using this value of the Tajima's D estimator, estimate via MCMC the expected value of the Tmrca
#    for the mutation experimental data, in units of (2N) (it's the haploid model). Call that time E.Tmrca
# 8- Now, repeat steps 1 through 7 BUT with the mutation experiment data. Get the theta estimate for the
#    mutation experiment and compare to the zebra's theta. Also, estimate the time to the mrca in units of 2N gens
# 9- PROBLEM: with both theta estimates and both Tmrca estimates (from mutation and zebras), can we find 
#    an estimate of the number of real generations back in the past until all the genes find a common ancestor IN THE ZEBRAS?
#    This number would give us the number of generations needed for the observed diversity coalesce back to a single infecting 
#    ancestor.   
# 10-SOLUTION: YES, WE CAN!! In the continuous coalescent, 2N discrete generations --> 1 continuous time unit.  Then
#   it follows that T continuous time units amount to T*2N discrete generations. 
#   If however, we know the amount of discrete generations (call it 'j') corresponding to T continous time units, then
#   we can set j= T*(2N), or N=j/(2*T).
#   In this case, we have j = 214 generations ellapsed in the mutation experiment
#                         T = E.Tmrca2, hence N=214/(2*E.Tmrca2).
# 11- This estimate of N is an estimate of the Effective population size:  the population size that would have to be
#   in order for the observations to come from a neutral Wright-Fisher.
# 12- With that estimate of N, I can now transform the zebra's estimate of the Tmrca, E.Tmrca = 1.64 (see code)
#     to units of real generation  
 
print(tmp)
print(tmp$zebnum)

new.tmp <- tmp[-which(tmp$zebnum==111,arr.ind=TRUE),]
where.minus9 <- which(new.tmp==-9,arr.ind=TRUE)
rows.w.minus9 <- as.numeric(names(table(where.minus9[,1])))
tmp2 <- new.tmp[-rows.w.minus9,-c(1,2)]
tmp3 <- tmp2
tmp.wznums <- new.tmp[-rows.w.minus9,2] # These are the zebra numbers to keep track of haplotypes' source
tmp.samps	<-	new.tmp[-rows.w.minus9,1]	
zebrasamps<-paste(tmp.wznums,tmp.samps,sep=".")

ninds <- nrow(tmp3)
ntotall <- ncol(tmp3)
mut.mat <- matrix(1,nrow=ninds,ncol=ntotall,dimnames=list(zebrasamps,tags))
colnames(mut.mat) <- tags

# Figuring out the most common allele per locus
for(i in 1:ntotall){
	
	ith.col <- tmp3[,i]
	freqspl <- sort(table(ith.col),decreasing=TRUE)
	m.fr.all<- as.numeric(names(freqspl))[1]
	where.mfrall <- which(ith.col==m.fr.all, arr.ind=TRUE)
	mut.mat[where.mfrall,i] <- 0	
	
}

nmuts.plocus <- apply(mut.mat,2,sum)
mut.mat2 <- mut.mat[,which(nmuts.plocus>0,arr.ind=TRUE)]
nsegreg <- ncol(mut.mat2)
# Computing the pairwise difference estimator of theta:

Sij.mat <- matrix(rep(0,ninds*ninds),nrow=ninds,ncol=ninds)
for(i in 1:ninds){
	for(j in 1:ninds){
		
		if((j==i)||(j<i)){Sij.mat[i,j]<-0}else{
			
			a <- mut.mat2[i,];
			b <- mut.mat2[j,];
			str.comp <- a!=b;
			pair.diffs <- sum(str.comp);
			Sij.mat[i,j] <- pair.diffs
		} 
		
	}
}

Dn <- (2/(ninds*(ninds-1)))*sum(Sij.mat)
var.Dn <- ((ninds+1)/(3*(ninds-1)))*Dn + (Dn^2)*(2*(ninds^2 + ninds + 3))/(9*ninds*(ninds-1))
sd.Dn <- sqrt(var.Dn)

######  Computing Watterson's estimator:
an <- function(n){an <- sum((1:(n-1))^(-1))}
bn <- function(n){bn <- sum(((1:(n-1))^(2))^(-1))}

theta.w.zeb <- nsegreg/an(ninds)
var.thetaw <-  (theta.w.zeb/(an(ninds))^2)*(an(ninds) + theta.w.zeb*bn(ninds));
sd.thetaw  <-  sqrt(var.thetaw);
#> theta.w.zeb
#[1] 1.620728
#> var.thetaw
#[1] 0.3759171
#> sd.thetaw
#[1] 0.6131208




#################  Before running the MCMC to estimate theta I calc the number of sampled
#################  sequences per haplotype using the matrix mut.mat2


mutmat2.char <-  rep("", nrow(mut.mat2))
nsegreg
ncol(mut.mat2)
for(i in 1:nrow(mut.mat2)){
	
	bb <- mut.mat2[i,]
	txt <- paste(rep("bb",nsegreg),"[",1:nsegreg,"],",sep="" )
	txt[nsegreg] <- "bb[10])"
	txt <- c("paste0(",txt)
	mutmat2.char[i] <- eval(parse(text=txt )) 	
	
}

zebnum.char <- as.character(tmp.wznums)
nhaplotypes.table <- table(mutmat2.char,zebnum.char)


M     <- 100000;
n     <- ninds;
nm1   <- n-1;
ss    <- nsegreg;
theta <- theta.w.zeb;#Dn;

Xv    <- 2:n;
Tv    <- 2/(Xv*(Xv - 1));
L     <- sum(Xv*Tv);


T.mat <- matrix(rep(0,(nm1*M)),nrow=M,ncol=nm1);
T.mat[1,] <- Tv;

Uvect    <- runif(M);
Tmrcav   <- rep(0,M);
Tmrcav[1]<- sum(Tv);

for (i in 2:M){
#Step 1:
        im1     <- i-1;
        old.Tv  <- T.mat[im1,]
        XT      <- rep(0,nm1);
        for(k in 1:nm1){XT[k] <- old.Tv[k]*Xv[k]}
        old.L   <- sum(XT); 

#Step 2:
        probs.samp <- rep(0,nm1);
		for (j in 1:nm1){probs.samp[j]<- (Xv[j]*old.Tv[j])/old.L};

		#x <- randX(1,xis=(2:n),probs = probs.samp)
		x          <- sample((2:n),size=1,prob=probs.samp) 
		x.ind      <- x-1;
		rate       <- (x*(x-1))/2;
		Tprimex    <- rexp(1,rate);
		Tx         <- old.Tv[x.ind];
		prop.Tv    <- old.Tv;
		prop.Tv[x.ind] <- Tprimex;
        XTprime    <- rep(0,nm1);
        for(h in 1:nm1){XTprime[h] <- prop.Tv[h]*Xv[h]}
        Lprime     <- sum(XTprime);

        #print(list(oTV = old.Tv,oL = old.L, soL = sum(old.Tv),pTV = prop.Tv, pL =Lprime,spl= sum(prop.Tv)))

#Step 3: The Metropolis Algorithm:
		A <- min(1,((exp((0.5*theta)*(-Lprime+old.L)))*((Lprime/old.L)^(ss-1))*(Tprimex/Tx)));
        #print(A)
        runif.test <- Uvect[i];
        if(runif.test<A){
                T.mat[i,]   <- prop.Tv;              
                Tmrcav[i]   <- sum(prop.Tv);
                }else{
           			T.mat[i,]   <- old.Tv
                	Tmrcav[i]   <- sum(old.Tv);                       
           }
}





sum(Tmrcav)/(M)
#[1] 1.901091

library(MASS)
write.matrix(Tmrcav, file= "Tmrcav100Thous.out")
write.matrix(mut.mat2, file="MutationMatrix.txt")

Tmrcavts <- as.ts(Tmrcav)
#acfcalc <- acf(x=Tmrcavts,lag.max=500)
#plot(Tmrcavts)

thinning <- seq(100,M,by=500)
length(thinning)

thinned.chain <- Tmrcavts[thinning[50:length(thinning)]]
#acfcalc <- acf(thinned.chain,lag.max=100)

median(thinned.chain)
#[1] 1.78874
E.Tmrca <- mean(thinned.chain)
#[1] 1.98328


par(mfrow=c(3,1))
hist(thinned.chain, main="Histogram, t.s. plot and acf for the MCMC chain of the TMRCA")
ts.plot(thinned.chain, xlab="Thinned chain", ylab="Tmrca")
acf(thinned.chain,lag.max=100, main="")
summary(thinned.chain)
#> summary(thinned.chain)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.5065  1.2580  1.7890  1.9830  2.4130  7.2390 

# Redefine the estimate of the Tmrca as the median=> skewed posterior dist.
E.Tmrca <- median(thinned.chain)
#> E.Tmrca
#[1] 1.78874

zebra.tmrca.chain <- thinned.chain

########   Now summarizing the configuration of the mutation experiment dataset

 
new.tmp2 <- tmp[which(tmp$zebnum==111,arr.ind=TRUE),]
where.minus9 <- which(new.tmp2==-9,arr.ind=TRUE)
rows.w.minus9 <- as.numeric(names(table(where.minus9[,1])))
tmp4 <- new.tmp2[-rows.w.minus9,-c(1,2)]
tmp5 <- tmp4
ninds2 <- nrow(tmp5)
ntotall2 <- ncol(tmp5)
mut.mat3 <- matrix(1,nrow=ninds2,ncol=ntotall2)
colnames(mut.mat3) <- tags

# Figuring out the most common allele per locus
for(i in 1:ntotall2){
	
	ith.col <- tmp5[,i]
	freqspl <- sort(table(ith.col),decreasing=TRUE)
	m.fr.all<- as.numeric(names(freqspl))[1]
	where.mfrall <- which(ith.col==m.fr.all, arr.ind=TRUE)
	mut.mat3[where.mfrall,i] <- 0	
	
}

nmuts.plocus2 <- apply(mut.mat3,2,sum)
mut.mat4 <- mut.mat3[,which(nmuts.plocus2>0,arr.ind=TRUE)]
nsegreg2 <- ncol(mut.mat4)
print(mut.mat4)
# And from this it is easy to see that there are 44 (0,0), 1 (1,0) and 1 (0,1)
# For loci Bam30 and HM.2

# Computing the pairwise difference estimator of theta:

Sij.mat2 <- matrix(rep(0,ninds2*ninds2),nrow=ninds2,ncol=ninds2)
for(i in 1:ninds2){
	for(j in 1:ninds2){
		
		if((j==i)||(j<i)){Sij.mat2[i,j]<-0}else{
			
			a <- mut.mat4[i,];
			b <- mut.mat4[j,];
			str.comp <- a!=b;
			pair.diffs <- sum(str.comp);
			Sij.mat2[i,j] <- pair.diffs
		} 
		
	}
}

Dn2 <- (2/(ninds2*(ninds2-1)))*sum(Sij.mat2)
var.Dn2 <- ((ninds2+1)/(3*(ninds2-1)))*Dn2 + (Dn2^2)*(2*(ninds2^2 + ninds2 + 3))/(9*ninds2*(ninds2-1))
sd.Dn2 <- sqrt(var.Dn2)

# Watterson's estimator:
theta.w.exp <- nsegreg2/an(ninds2)
var.thetaw.exp <-  (theta.w.exp/(an(ninds2))^2)*(an(ninds2) + theta.w.exp*bn(ninds2));
sd.thetaw.exp  <-  sqrt(var.thetaw.exp);
theta.w.exp
var.thetaw.exp
sd.thetaw.exp
#> theta.w.exp
#[1] 0.4550679
#> var.thetaw.exp
#[1] 0.1209435
#> sd.thetaw.exp
#[1] 0.3477694


########  Now running the MCMC to estimate the TMRCA using the theta.hat estimate from the mutation experiment:
M     <- 100000;
n     <- ninds2;
nm1   <- n-1;
ss    <- nsegreg2;
theta <- theta.w.exp;

Xv    <- 2:n;
Tv    <- 2/(Xv*(Xv - 1));
L     <- sum(Xv*Tv);


T.mat <- matrix(rep(0,(nm1*M)),nrow=M,ncol=nm1);
T.mat[1,] <- Tv;

Uvect     <- runif(M);
Tmrcav2   <- rep(0,M);
Tmrcav2[1]<- sum(Tv);

for (i in 2:M){
#Step 1:
        im1     <- i-1;
        old.Tv  <- T.mat[im1,]
        XT      <- rep(0,nm1);
        for(k in 1:nm1){XT[k] <- old.Tv[k]*Xv[k]}
        old.L   <- sum(XT); 

#Step 2:
        probs.samp <- rep(0,nm1);
		for (j in 1:nm1){probs.samp[j]<- (Xv[j]*old.Tv[j])/old.L};

		#x <- randX(1,xis=(2:n),probs = probs.samp)
		x          <- sample((2:n),size=1,prob=probs.samp) 
		x.ind      <- x-1;
		rate       <- (x*(x-1))/2;
		Tprimex    <- rexp(1,rate);
		Tx         <- old.Tv[x.ind];
		prop.Tv    <- old.Tv;
		prop.Tv[x.ind] <- Tprimex;
        XTprime    <- rep(0,nm1);
        for(h in 1:nm1){XTprime[h] <- prop.Tv[h]*Xv[h]}
        Lprime     <- sum(XTprime);

        #print(list(oTV = old.Tv,oL = old.L, soL = sum(old.Tv),pTV = prop.Tv, pL =Lprime,spl= sum(prop.Tv)))

#Step 3: The Metropolis Algorithm:
		A <- min(1,((exp((0.5*theta)*(-Lprime+old.L)))*((Lprime/old.L)^(ss-1))*(Tprimex/Tx)));
        #print(A)
        runif.test <- Uvect[i];
        if(runif.test<A){
                T.mat[i,]   <- prop.Tv;              
                Tmrcav2[i]   <- sum(prop.Tv);
                }else{
           			T.mat[i,]   <- old.Tv
                	Tmrcav2[i]   <- sum(old.Tv);                       
           }
}





sum(Tmrcav2)/(M)
#> sum(Tmrcav2)/(M)
#[1] 1.93982
Tmrcavts2 <- as.ts(Tmrcav2)

thinning <- seq(100,M,by=500)
length(thinning)

thinned.chain2 <- Tmrcavts2[thinning[50:length(thinning)]]
#acfcalc <- acf(thinned.chain,lag.max=100)

median(thinned.chain2)
E.Tmrca2 <- median(thinned.chain2)
#> E.Tmrca2
#[1] 1.60457

par(mfrow=c(3,1))
hist(thinned.chain2, main="Histogram, t.s. plot and acf for the MCMC chain of the TMRCA")
ts.plot(thinned.chain2, xlab="Thinned chain", ylab="Tmrca")
acf(thinned.chain2,lag.max=100, main="")
summary(thinned.chain2)
#> summary(thinned.chain2)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.6901  1.2530  1.6050  1.8600  2.3270  4.9120 

lab.tmrca.chain <- thinned.chain2

# Num. gens in lab
ngens.lab <- 214 # Given by Ryan = experiment duration
Ne.lab <- ngens.lab/(2*E.Tmrca2) # 214 generations from mutation experiment data
#> Ne.lab
#[1] 66.68453

# and the mutation rate  from the lab is then:
mu.hat <- theta.w.exp/(2*Ne.lab)
#> mu.hat
#[1] 0.003412095



# So a conservative estimate of the number of generations 'jm.hat' until one recent common ancestor
# Given the diversity observed in the sample will be computed by
# considering that the population in a zebra is (Factor=M) times bigger than in the lab
# per Wendy Turner:  final lab population size amounts to population size in two dead zebras
# and since the data came from 11 zebras, we can set  that multiplier at 5.5 = 11/2
M.multip <- 5.5
Ne.zebs <- Ne.lab*M.multip
#> Ne.zebs
#[1] 366.7649
jm.hat <- E.Tmrca*2*Ne.zebs
print(jm.hat)
#> print(jm.hat)
#[1] 1312.094

# Computing the number of gens per day, we can estimate the number of days until 'jm.hat'
ngens.pday <- ngens.lab/6
num.days<- jm.hat/ngens.pday
print(num.days)
#[1] 36.78769

## And the mutation rate in the zebra is then:  2*Ne.lab*M.multip*mu = Dn ==> mu = Dn/(2*Ne.lab*M.multip)
mu.hat.zebras <- theta.w.zeb/(2*Ne.lab*M.multip)
#> mu.hat.zebras
#[1] 0.002209492

# Compare both mutation rates:
print(mu.hat)
print(mu.hat.zebras)
#> print(mu.hat)
#[1] 0.003412095
#> print(mu.hat.zebras)
#[1] 0.002209492



# Estimate the initial population size in each zebra along with the number of different variants on average
# Assuming 1,2,3,4,5,6,7,8,9 days


# What we need is:

# 1. Use growth rate computed by using the time in generations and No = Ne.lab

beta <- (log(Ne.lab) - log(1))/ngens.lab
#> beta
#[1] 0.01930657

# 2. If I start a simulation at Ne.start and select an exponential time at which something
#    will happen (either a mutation or a coalescence) -say tau-, then the question is: what will the Ne
#    for the next step be? to do that, we first transform from tau units in coalescence time to 'j' real generations  

j.gens.calc <- function(beta,tau,N){return((1/beta)*log(2*beta*N*tau +1))}

# 3. Then, with the real generations till that event, we use the exponential decay function to project
#    the next Ne size:
Ne.nextcalc <- function(Ne.start,j.gens,beta){ return(Ne.start*exp(-beta*j.gens))}

# 4. With these two functions in hand, now I can write a coalescent simulator function
#    where the arguments are mu, Ne.start (Ne at the present), number of genes at present (k),
#    number of different types, number of individuals of each type


save.image(file="ZebrasAnalysis2.RData")

coal.sim.exp <- function(beta,mu,Ne.init,haplo.config){
	
	# beta = exponential growth rate
	# mu = unscaled mutation rate per individual generation
	
	k <- sum(haplo.config) # initial (present) number of genes
	
	genes <- list()
	
	
}




