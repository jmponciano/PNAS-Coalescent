setwd("~/Dropbox/JuanPabloThesis/PostDoc")
library("spBayes")
source("CoalToolkit.R")
library("snow")
# Testing the amcmc algorithm
# I used the spBayes which has the adaptMetropGibss function which is a wrapper 
# function from the amcmc package. 
# The target functions are defined in the CoalToolkit.R source code.

theta.0 <- 0.44
n		<- 30
beta 	<- 0.001
true.tree <- rcoal.exp(n=n, beta=beta,compare=FALSE,with.mut=TRUE, theta.0=theta.0)
s	<-	true.tree$n.segreg

x0	<- c(runif(1,-4,4),runif(1,-1,1), log(us.calc(phy=rcoal(n))))
x1	<- c(runif(1,-4,4),runif(1,-1,1), log(us.calc(phy=rcoal(n))))

X	<-	matrix(0,nrow=4,ncol=n+1)

for(i in 1:4){
	
	X[i,]	<-	c(runif(1,-4,4),runif(1,-1,1), log(us.calc(phy=rcoal(n))))
	
}

mcmc.run	<-	function(r){
	
	inits	<-	X[r,]
	n.batch	<-	10000
	batch.length	<-	25
	adaptMetropGibbs(ltd=Exp.post,starting=inits,tuning=1,batch=n.batch,batch.length=batch.length)
	
}


cl		<-	makeCluster(4,"SOCK")
clusterEvalQ(cl,library("spBayes"))
clusterEvalQ(cl,source('~/Dropbox/JuanPabloThesis/PostDoc/CoalToolkit.R', chdir = TRUE))
clusterExport(cl,list("s","X"))
par.samples	<-	clusterApply(cl,1:4,mcmc.run)
stopCluster(cl)

mcmc.run	<-	mcmc.list()

for(i in 1:4){
	
	mcmc.run[[i]]	<-	par.samples[[i]]$p.theta.samples[,1:2]
	
}


