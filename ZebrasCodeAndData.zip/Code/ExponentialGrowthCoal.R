source("CoalToolkit.R")


####------- Main procedural section -------#

theta.0 <- 0.44
n <- 12
# Transform the simulated times into times from an exponential model:
beta <- 100
two.trees <- rcoal.exp(n=n,beta=beta, compare=TRUE)
tmp <- two.trees$cstN.tree
tmp2<- two.trees$exp.tree

dcoal(phy=tmp,theta=theta.0 , log=TRUE)
dcoal.time(phy=tmp2, theta0=theta.0, rho=beta,log=TRUE)

par(mfrow=c(1,2))
plot(tmp)
nodelabels()

plot(tmp2)
nodelabels()


# Checking the likelihood:  

test.brtimes <- c(branching.times(tmp2),0)
theta.0 <- 0.44; 
beta <- beta;

Exp.negll(theta.0=theta.0,beta=beta,br.times=test.brtimes)

-dcoal.time(phy=tmp2, theta0=theta.0, rho=-beta,log=TRUE) # Paradis is missing a log(2)

#------------------------------ Using rtwalk:------------------------------##
# First, set the initial values for the bayesian paramters (true parameters + hidden vars.)
theta.0 <- 0.44
n		<- 12
beta 	<- 100
us0     <- rexp(2/((2:n)*((2:n)-1)))
us0     <- us0/sum(us0)
us0p     <- rexp(2/((2:n)*((2:n)-1)))
us0p     <- us0p/sum(us0p)

x0		    <- c(theta.0, beta, us0)
x0prime		<- c(theta.0+0.3, beta-10, us0p)
# Setting the global variables
s	<<-	10
dim.parms <<- length(x0)

niters <- 200000

Exp.post(params=x0)

First.trial <- Runtwalk(Tr= niters, dim=dim.parms, Obj=Exp.post, Supp=Exp.Supp,x0=x0, xp0=x0prime,PlotObj=FALSE, PlotLogPost=FALSE)

# Thinning:
burn.in  <- 20000
thinning <- seq(from=burn.in,to= niters, by= 50)
sampled.chain1 <- First.trial$output[thinning,1:2]

theta.0.post <- (sampled.chain1[,1])
beta.post    <- (sampled.chain1[,2])

par(mfrow=c(2,2))
hist(theta.0.post)
hist(beta.post)
plot(1: length(First.trial$Us[thinning]), First.trial$Us[thinning], type="l")
hist(First.trial$Ups)


#------------Second trial: simulate a tree to check posterior-----------#

theta.0 <- 0.44
n		<- 30
beta 	<- 0.001
true.tree <- rcoal.exp(n=n, beta=beta,compare=FALSE,with.mut=TRUE, theta.0=theta.0)
true.tree

us0 <- us.calc(phy=true.tree$phy)
us0p <- us0*0.7
x0		    <- c(theta.0, beta, us0)
x0prime		<- c(theta.0+0.3, beta*0.7, us0p)

# Setting the global variables
s	<<-	true.tree$n.segreg
dim.parms <<- length(x0)
niters <- 700000

Second.trial <- Runtwalk(Tr= niters, dim=dim.parms, Obj=Exp.post, Supp=Exp.Supp,x0=x0, xp0=x0prime,PlotObj=FALSE, PlotLogPost=FALSE)

# Thinning:
burn.in  <- 200000
thinning <- seq(from=burn.in,to= niters, by= 50)
sampled.chain2 <- Second.trial$output[thinning,1:2]

theta.0.post <- (sampled.chain2[,1])
beta.post    <- (sampled.chain2[,2])

mean(theta.0.post)
theta.0

mean(beta.post)
beta


par(mfrow=c(2,2))
hist(theta.0.post)
hist(beta.post)
plot(1: length(Second.trial$Us[thinning]), Second.trial$Us[thinning], type="l")
plot(1: length(Second.trial$Ups[thinning]), Second.trial$Ups[thinning], type="l")


####-------------------------------------- Trying with data cloning -------------------------#

# post \propto (f(y|thetas,beta)g(theta,beta,coal.times))^k *unif.priors(theta,beta,coal.times)


nclones <- 20
niters <- 1000000
frac.2burn <- 0.9
burn.in  <- niters*frac.2burn
lag      <- 50 
thinning <- seq(from=burn.in,to= niters, by= 50)


theta.0 <- 0.44
n		<- 30
beta 	<- 0.001
true.tree <- rcoal.exp(n=n, beta=beta,compare=FALSE,with.mut=TRUE, theta.0=theta.0)
true.tree

us0 <- rep(us.calc(phy=true.tree$phy),nclones)
us0p <- us0*0.7
x0		    <- c(theta.0, beta, us0)
x0prime		<- c(theta.0+0.3, beta*0.7, us0p)

# Setting the global variables
s	<<-	true.tree$n.segreg
dim.parms <<- length(x0)


DC.trial <- Runtwalk(Tr= niters, dim=dim.parms, Obj=Exp.post.DC, Supp=Exp.Supp,x0=x0, xp0=x0prime,PlotObj=FALSE, PlotLogPost=FALSE)

DC.chain1 <- DC.trial$output[thinning,1:2]

theta.0.dcpost <- (DC.chain1[,1])
beta.dcpost    <- (DC.chain1[,2])

theta.0.hat <- mean(theta.0.dcpost)
theta.0.hat
theta.0

beta.hat <- mean(beta.dcpost)
beta.hat
beta


par(mfrow=c(2,2))
hist(theta.0.dcpost)
abline(v=theta.0.hat, col="red", lwd=2)
hist(beta.dcpost)
abline(v=beta.hat, col="red", lwd=2)
plot(1: length(theta.0.dcpost), theta.0.dcpost, type="l")
plot(1: length(beta.dcpost), beta.dcpost, type="l")

plot(1: length(DC.trial$Us[thinning]), DC.trial$Us[thinning], type="l")
plot(1: length(DC.trial$Ups[thinning]), DC.trial$Ups[thinning], type="l")

#### Testing expcoal.estim.function
theta0.init <- c(0.1,0.1+0.3)
beta.init 	<- c(0.1,0.1*0.7)
n			<- 29
nsegreg		<-	4
nclones		<-	2
niters		<-	10000
frac.2burn	<-	0.1
lag			<-	10

DC.estim	<-	expcoal.estim(n=n,nsegreg=nsegreg,nclones=nclones,theta0.init=theta0.init,beta.init=beta.init,niters=niters,lag=lag
								,frac2burn=frac.2burn,plot.res=TRUE)
							
## Now running in parallel the same process varying K from 1 to 35

nsegreg.samps	<-	rep(0,1000)

for(i in 1:1000){
	tree			<-	rcoal.exp(29,5.5,theta.0=0.58,with.mut=TRUE)
	nsegreg.samps[i]<-	tree$n.segreg
}
barplot(table(nsegreg.samps),space=0)
round(mean(nsegreg.samps))

# Zebra 1 n = 29 and nsegreg = 4. To obtain that you need beta = 0.01 and theta = 0.5
k	<-	c(1,2,4,8,16,20,25,30,35)

estimation	<-	function(r){
	
	theta0.init <- c(0.1,0.1+0.3)
	beta.init 	<- c(0.1,0.1*0.7)
	n			<- 29
	nsegreg		<-	4
	nclones		<-	k[r]
	niters		<-	1000000
	frac.2burn	<-	0.9
	lag			<-	50

	DC.estim	<-	expcoal.estim(n=n,nsegreg=nsegreg,nclones=nclones
								,theta0.init=theta0.init,beta.init=beta.init
								,niters=niters,lag=lag,frac2burn=frac.2burn)
	DC.estim
	
}

library(snow)
n.ks	<-	length(k)
cl		<-	makeCluster(n.ks,"SOCK")
clusterEvalQ(cl,"CoalToolkit.R")
clusterExport(cl,list("k"))
par.samples	<-	clusterApply(cl,1:n.ks,estimation)

hats		<-	matrix(0,ncol=2,nrow=n.ks,dimnames=list(k,c("theta0","beta")))
eigen.vals	<-	matrix(0,ncol=2,nrow=n.ks,dimnames=list(k,c("Chain1","Chain2")))

for(i in 1:n.ks){
	
	hats[i,]			<-	summary(par.samples[[i]][[1]])$statistics[,1]
	eigen.vals[i,1]		<-	eigen(cov(par.samples[[i]][[1]][[1]]))$values[1]
	eigen.vals[i,1]		<-	eigen(cov(par.samples[[i]][[1]][[2]]))$values[1]
	
}


##### Testing the new functions with fixed theta.0
source("CoalToolkit2.R")

n	<-	29
nsegreg	<-	4
nclones	<-	1
niters	<-	2000000
frac.2burn	<-	0.2
lag		<-	10
theta.0	<-	0.44
beta.init 	<- c(0.1,0.1*0.7)

DC.estim	<-	expcoal.estim(n=n,nsegreg=nsegreg,nclones=nclones,theta0=theta.0
								,beta.init=beta.init,niters=niters,frac2burn=frac.2burn,plot.res=TRUE,lag=lag
								,prior.pdf="lnorm")

ch.1		<-	DC.estim$mcmc.samples[[1]]
ch.2		<-	DC.estim$mcmc.samples[[1]]

plot(100000:160000,ch.1[100000:160000,1],type="l")




