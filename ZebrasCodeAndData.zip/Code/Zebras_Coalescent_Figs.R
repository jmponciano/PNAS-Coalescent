##################################################################################
# Code to produce teh figures resultig from the estimation of the time to most
# recent common ancestor of samples of B. anthracis taken from 11 zebras. This code
# is based on the results produced from the MHcoalescent.R code. Last Revised May 16 2017
##################################################################################
# Figure 1
labeled.tree <- function(my.path="~/Desktop/tree_sample.tiff"){

	# Plot of a cladogram with 7 tips showing all of the variables
	tiff(my.path,width=11,height=8.5,units="in",res=300,compression="lzw",type="cairo",family="times")
	n	<-	7
	beta<-	20
	cex.txt	<-	2
	set.seed(456)
	tmp	<-	rcoal.exp(n,beta)
	my.brtimes	<-	branching.times(tmp)
	plot.brtimes<-	c(max(my.brtimes)-my.brtimes,max(my.brtimes))
	us			<-	us.calc(tmp)
	par(oma=c(3,1,3,1))
	plot(tmp,no.margin=TRUE,type="cladogram",show.tip.label=FALSE,edge.width=2)
	abline(v=plot.brtimes,lty=2,col="red",lwd=2)
	axis(1,at=plot.brtimes,labels=expression(t[1],t[2],t[3],t[4],t[5],t[6],t[7]==0),cex.axis=cex.txt)
	axis(3,at=plot.brtimes, labels=expression(theta[1], theta[2], theta[3], theta[4], theta[5], theta[6], 	
	theta[0]), lwd=0, cex.axis=cex.txt)
	axis(1,at=plot.brtimes[1:(n-1)]+us/2,labels=expression(u[2], u[3], u[4], u[5], u[6], u[7]), lwd=0, 
	line=-0.5, cex.axis=cex.txt)
	axis(4,at=1:7,labels=1:7,lwd=0,mgp=c(0,-2.5,0),las=2,cex.axis=cex.txt)
	dev.off()
}

##################################################################################
# Figure 2
zeb.nums	<-	rownames(zeb.only)
y.max		<-	c(15000,15000,20000,15000,15000,15000,20000,15000,15000,15000,20000)
x.lim1		<-	matrix(c(0,300,0,300,0,300,0,150,0,150,0,300,0,100,10,150,0,300,0,300,0,200),ncol=2,byrow=TRUE)
x.lim2		<-	matrix(c(1,1.8,1,1.8,0.5,1.5,1.5,2.5,1.5,3.5,0.8,1.8,0.6,0.8,1.5,3.5,0.8,1.8,1.1,2.1,1,2.2),ncol=2,byrow=TRUE)
zeb.order	<-	order(as.numeric(colnames(const.tmrca)))

tiff("~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/Figure_2.tiff",width=9,height=6.5,units="in"
	,res=300,compression="lzw",type="cairo",family="times")
mat.vec	<-	c(1:2,0,3:4,0,5:6,7:8,0,9:10,0,11:12,13:14,0,15:16,0,17:18,19:20,0,21:22,0,23,23)
mat	<-	matrix(mat.vec,ncol=8,nrow=4,byrow=TRUE)

layout(mat,widths=c(1,1,0.25,1,1,0.25,1,1))
par(tcl=-0.25,mgp=c(2,0.5,0),oma=c(2,3.5,1,1))
for(j in 1:11){
	i	<-	zeb.order[j]	
	par(mar=c(3,0.5,0.5,0.5))
	hist(const.tmrca[,i],col="black",main="",xlab="",ylab=""
		,freq=TRUE,ylim=c(0,y.max[i]),border="white",yaxt="n",xlim=x.lim1[i,],xaxp=c(x.lim1[i,1],x.lim1[i,2],2))
	abline(v=mean(const.tmrca[,i]),lwd=2,col="red")
	axis(2,at=seq(0,y.max[i],length=3),labels=seq(0,y.max[i],length=3)/1000,lwd=0,lwd.ticks=1)
	box(bty="l")
	par(mar=c(3,0.5,0.5,0.5))
	hist(exp.tmrca[,i],col="grey",border="black",main="",freq=TRUE,xlab="",ylab="",ylim=c(0,y.max[i]),yaxt="n"
		,xlim=x.lim2[i,],xaxp=c(x.lim2[i,1],x.lim2[i,2],2))
	abline(v=mean(exp.tmrca[,i]),lwd=2,col="red")
	#box(bty="l",lty=2,col="grey")
	axis(1,labels=FALSE,lwd.ticks=0)
	mtext(paste("Zebra No.",zeb.nums[i],sep=" "),adj=-1,line=-1,cex=0.75)
	#axis(1,at=c(0,3,6,9,12),labels=c(0,3,6,9,expression(""<=12)))
}
plot(0,1,type="n",axes=FALSE,xlab=" ",ylab=" ",xlim=c(0,1),ylim=c(0,1))
legend(0,1,c("Constant\nPopulation Size","Exponential\nPopulation Size")
		,fill=c("black","grey"),border=c("black","grey")
		,bty="n",y.intersp=1.75,cex=1.5)
mtext("Days to Most Recent Common Ancestor",side=1,outer=TRUE)
mtext("Frequency/1000",side=2,outer=TRUE,line=1.5)

dev.off()
