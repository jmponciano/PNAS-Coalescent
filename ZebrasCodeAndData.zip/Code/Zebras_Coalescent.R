##################################################################################
# Code to estimate the TMRCA of the B. anthracis data set for 11 zebras and a lab experiment.
# This code and functions where developed by JM Ponciano and JP Gomez. Current version was revised
# in May 16 2017.

##################################################################################
#					 Required packages and sources
library(ape)
library(rjags)
library(snow)

##################################################################################
#						Functions required

# Transformation of TMRCA from coalescent times to generation
# assuming constant population size
j.transf	<-	function(tmrca,N0,beta){
	
	(1/beta)*log((beta*N0*tmrca)+1)
	
}

# Negative log likelihood of the Coalescent model with constant population size
Const.nll	<-	function(s,us,theta){
	
	nm1		<-	length(us)
	n		<-	nm1 + 1
	L		<-	sum(us*2:n)
	lambda	<-	theta*L*0.5
	neg.ll.1 <- -dpois(s,lambda,log=TRUE)
	rate	<-	(2:n*((2:n)-1))/2
	neg.ll.2<-	rep(0,nm1)
	for(i in 1:nm1){
		
		neg.ll.2	<-	-dexp(us[i],rate[i],log=TRUE)
		
		
	}
	neg.ll	<-	neg.ll.1 + sum(neg.ll.2)
	return(neg.ll)
	
}

# Negative log likelihood of the coalescent model assuming exponential population growth
Exp.mut.nll	<-	function(s=s,us,theta.0,beta){

	# us = u2,u3,...,un; length(us)=n-1;
	ltheta.0 <- log(theta.0);
	ln2      <- log(2);
	nm1 <- length(us);
	n   <- nm1+1;
	lncombs <-  lchoose(n=(2:n), 2);
	ncombs   <- exp(lncombs)
	my.brtimes	<-	rep(0,n)
	for(i in 1:nm1){my.brtimes[i] <- sum(us[i:nm1])}
	names(my.brtimes)	<-	paste0("t",1:n)
	tkm1s   <- my.brtimes[-n]
	tks     <- my.brtimes[-1]
	thetas	<-	theta.0*exp(-beta*my.brtimes)
	names(thetas)	<-	c(paste0("theta",1:nm1),"theta0")
	theta	<-	sum(thetas[1:nm1]*us)
	L		<-	sum(us*2:n)
	lambda	<-	theta*L*0.5
	neg.ll.1 <- -dpois(s,lambda,log=TRUE)
	neg.ll.2 <- -sum(lncombs + ln2 + beta*tkm1s-ltheta.0 
			-2*(ncombs/(theta.0*beta))*(exp(beta*tkm1s)-exp(beta*tks)))
	neg.ll	<-	neg.ll.1 + neg.ll.2
	return(neg.ll)

}

##################################################################################
#								Jags models				
# Coalescent model with exponential growth
sink("coalescent_mod.txt")
cat("
	model{


	# Priors
	
	# We need only priors for theta0 and beta
		theta0	~	dunif(0,20)
		beta		~	dunif(0,200)
	
	# Model
	# Loop along Clones

	for(k in 1:K){	
				
		# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
		for(i in 1:(n[k]-1)){ # From past to present
				
			h[i,k]			<-	i+1
			i.ch2[i,k]		<-	(h[i,k]*(h[i,k]-1))/2
			us[i,k]			~	dexp(i.ch2[i,k])
			us.exp[i,k]		<-	(exp(-us[i,k]*beta)-1)/(-beta)
		
			} # end individuals loop
		
		for(i in 1:(n[k]-1)){
				
			br.times[i,k]	<-	sum(us.exp[1:(n[k]-i),k])
			theta.i[i,k]	<-	theta0*exp(-beta*(br.times[i,k]))			
			lambda.i[i,k]	<-	(theta.i[i,k]*us.exp[i,k]*(i+1))/2

		}
			
		tmrca[k]	<-	br.times[1,k]
		lambda[k]	<-	sum(lambda.i[,k])			
		s[k] 		~ 	dpois(lambda[k]) # Number of mutations across the tree

	} # end clones loop
	
}")
sink()

# Sampling from the coalescent model with exponential growth
sink("coalescent_kalman.txt")
cat("
	model{

	# Model				
	# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
	for(i in 1:(n-1)){ # From past to present
				
		h[i]			<-	i+1
		i.ch2[i]		<-	(h[i]*(h[i]-1))/2
		us[i]			~	dexp(i.ch2[i])
		us.exp[i]		<-	(exp(-us[i]*beta)-1)/(-beta)
	
	} # end individuals loop
		
	for(i in 1:(n-1)){
		
		br.times[i]	<-	sum(us.exp[1:(n-i)])
		theta.i[i]	<-	theta0*exp(-beta*(br.times[i]))			
		lambda.i[i]	<-	(theta.i[i]*us.exp[i]*(i+1))/2			
			
	}
			
	tmrca		<-	br.times[1]
	lambda		<-	sum(lambda.i)			
	s	 		~ 	dpois(lambda) # Number of mutations across the tree
		
}")
sink()

# Coalescent Model with constant population size
sink("coalescent_const.txt")
cat("
	model{
	
	# Prior for theta
	theta	~	dunif(0,10)

	# Model
	# Loop along Clones

	for(k in 1:K){	
		
		# Loop along Zebras
		
		# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
		for(i in 1:(n[k]-1)){ # From past to present
				
			h[i,k]			<-	i+1
			i.ch2[i,k]		<-	(h[i,k]*(h[i,k]-1))/2
			us[i,k]			~	dexp(i.ch2[i,k])
			sum.us[i,k]		<-	us[i,k]*h[i,k]				
		
		} # end individuals loop
			
		tmrca[k]	<-	sum(us[,k])
		lambda[k]	<-	theta/2*sum(sum.us[,k])
					
		s[k] 		~ 	dpois(lambda[k]) # Number of mutations across the tree

	} # end clones loop
	
}")
sink()

# Sample the Coalescent Model with constant population size
sink("coalescent_const.txt")
cat("
	model{
	
	# Prior for theta
	theta	~	dunif(0,10)

	# Model
	# Loop along Clones

	for(k in 1:K){	
		
		# Loop along Zebras
		
		# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
		for(i in 1:(n[k]-1)){ # From past to present
				
			h[i,k]			<-	i+1
			i.ch2[i,k]		<-	(h[i,k]*(h[i,k]-1))/2
			us[i,k]			~	dexp(i.ch2[i,k])
			sum.us[i,k]		<-	us[i,k]*h[i,k]				
		
		} # end individuals loop
			
		tmrca[k]	<-	sum(us[,k])
		lambda[k]	<-	theta/2*sum(sum.us[,k])
					
		s[k] 		~ 	dpois(lambda[k]) # Number of mutations across the tree

	} # end clones loop
	
}")
sink()

# Sampling from the Coalescent model with constant population size
sink("coalescent_const_kalman.txt")
cat("
	model{
	
	# Model	
	# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
	for(i in 1:(n-1)){ # From past to present
				
		h[i]			<-	i+1
		i.ch2[i]		<-	(h[i]*(h[i]-1))/2
		us[i]			~	dexp(i.ch2[i])
		sum.us[i]		<-	us[i]*h[i]				
		
	} # end individuals loop
			
	tmrca	<-	sum(us)
	lambda	<-	theta/2*sum(sum.us)
					
	s 		~ 	dpois(lambda) # Number of mutations across the tree
	
}")
sink()

##################################################################################
#			Obtaining and organizing the data
# There are 11 zebras and one experiment data. The experiment corresponds to the line 
# labeled as 111. 

zeb.file	<-	read.delim("ZebraSNR.txt")
zebnum		<-	unique(zeb.file[,2])
zeb.data	<-	matrix(0,ncol=2,nrow=length(zebnum),dimnames=list(zebnum,c("N","N.segreg")))

# Extracting Data
for (i in 1:length(zebnum)){
	zeb1		<-	zeb.file[zeb.file[,2]==zebnum[i],]
	missing.dat	<-	unique(which(zeb1==-9,arr.ind=TRUE)[,1])
	if(length(missing.dat)==0){zeb1	<-	zeb1[,-c(1,2)]}else{
	zeb1	<-	zeb1[-missing.dat,-c(1,2)]}
	nalleles	<-	apply(zeb1,2,function(x)length(unique(x)))
	segreg.sites<-	length(which(nalleles>1))
	n.inds		<-	nrow(zeb1)
	zeb.data[i,]	<-	c(n.inds,segreg.sites)
}

lab.pos		<-	which(rownames(zeb.data)==111)
zeb.only	<-	zeb.data[-lab.pos,]

##################################################################################
#		Obtaining the haplotypes in Zebra 2. Table for Appendix
zebra2				<-	zeb.file[which(zeb.file[,2]==2),]
missing.dat			<-	unique(which(zebra2==-9,arr.ind=TRUE)[,1])
zebra2.full				<-	zebra2[-missing.dat,3:ncol(zebra2)]
n.vars				<-	apply(zebra2.full,2,function(x)length(unique(x,na.rm=TRUE)))
zebra2.hap			<-	zebra2.full
zebra2.hap[n.vars==1]	<-	0
segreg.sites		<-	which(n.vars>1)
for(i in 1:length(segreg.sites)){
	
	ith.segreg	<-	zebra2.full[,segreg.sites[i]]
	ith.counts	<-	table(ith.segreg)
	wild.type	<-	names(ith.counts)[which.max(ith.counts)]
	types		<-	rep(1,length(ith.segreg))
	types[ith.segreg==wild.type]	<-	0
	zebra2.hap[,segreg.sites[i]]	<-	types		
}

haplotypes	<-	rep(NA,nrow(zebra2.hap))

for(i in 1:nrow(zebra2.hap)){
	
	haplotypes[i]	<-	paste(zebra2.hap[i,],collapse="",sep="")	
	
		
}

hap.freq	<-	data.frame(table(haplotypes))

counts.tab	<-	matrix(0,ncol=5,nrow=nrow(hap.freq))

for (i in 1:length(segreg.sites)){
	
	counts.tab[,i]	<-	as.numeric(substr(hap.freq[,1],segreg.sites[i],segreg.sites[i]))
	
}

counts.tab[,5]	<-	hap.freq[,2]
colnames(counts.tab)	<-	c(names(segreg.sites),"Frequency")
##################################################################################
# Obtaining the Haplotypes for each zebra and their counts

missing.dat	<-	unique(which(zeb.file==-9,arr.ind=TRUE)[,1])
all.zebras	<-	zeb.file[-missing.dat,]
all.zebras	<-	all.zebras[order(all.zebras[,2]),]

hap.mat	<-	NULL

for(i in 1:length(zebnum)){

	ith.pos		<-	which(all.zebras[,2]==zebnum[i])
	ith.zebra	<-	all.zebras[ith.pos,-c(1,2)]
	ith.haps	<-	matrix(0,ncol=ncol(ith.zebra),nrow=nrow(ith.zebra))
	n.alleles	<-	apply(ith.zebra,2,function(x)length(unique(x,na.rm=TRUE)))
	n.vars		<-	which(n.alleles>1)
	for(j in 1:length(n.vars)){
		
		jth.loci	<-	ith.zebra[,n.vars[j]]
		jth.loci.vec<-	rep(1,length(jth.loci))
		common.allele<-	which.max(table(jth.loci))
		jth.loci.vec[jth.loci==names(common.allele)]	<-	0
		ith.haps[,n.vars[j]]	<-	jth.loci.vec
		
	}
	
	hap.mat	<-	rbind(hap.mat,ith.haps)
	
}

all.haplotypes	<-	rep(NA,nrow(hap.mat))

for(i in 1:nrow(hap.mat)){
	
	all.haplotypes[i]	<-	paste(hap.mat[i,],collapse="",sep="")	
	
}

tmp.df	<-	data.frame(Zebra=all.zebras[,2],Haplotypes=all.haplotypes)

hap.frequencies	<-	table(tmp.df$Haplotypes,tmp.df$Zebra)

write.table(hap.frequencies,"haplotype_frequencies.txt",sep="\t",quote=FALSE)

##################################################################################
# First, estimate the TMRCA of the experiment assuming constant population size

K 			<-	70
n.experiment<-	zeb.data[lab.pos,1]
s.experiment<-	zeb.data[lab.pos,2]

n.clons		<-	rep(n.experiment,K)
s.clons		<-	rep(s.experiment,K)

params		<-	c("theta")
data.list	<-	list(n=n.clons,s=s.clons,K=K)

jm.experiment	<-	jags.model(file="coalescent_const.txt",data=data.list,n.chains=2,n.adapt=5000)
out.experiment	<-	coda.samples(model=jm.experiment,variable.names=params,n.iter=100000,thin=100)

theta.experiment<-	summary(out.experiment)$statistics[1]

# Obtain time to most recent common ancestor sampling the posterior distribution of the coalescent model
data.list		<-	list(n=n.experiment,s=s.experiment,theta=theta.experiment)
jm.sample.exper	<-	jags.model(file="coalescent_const_kalman.txt",data=data.list,n.chains=1,n.adapt=1000)
out.sample.exper<-	coda.samples(model=jm.sample.exper,variable.names="tmrca",n.iter=500000,thin=1)

# Use the time to most recent common ancestor to calculate the MLVA and SNR mutation rate
tmrca.experiment<-	out.sample.exper[[1]][,1]
ngens.experiment<-	214
Ne.experiment.vec	<-	ngens.experiment/(tmrca.experiment)
mut.rate.vec		<-	theta.experiment/(2*Ne.experiment.vec)
Ne.experiment		<-	median(Ne.experiment.vec)
mut.rate			<-	median(mut.rate.vec)

# Profile likelihood for theta to estimate the confidence interval of the mutation rate.
# First sample the coalescent model to obtain samples of the Us
out.us.samp.exper	<-	coda.samples(model=jm.sample.exper,variable.names="us",n.iter=500000,thin=1)
us.samp.exper	<-	as.matrix(out.us.samp.exper[[1]])
theta.seq		<-	seq(0.01,4,length=100)
PofThpgUS		<-	matrix(0,nrow=50000,ncol=100)
PofThgUS		<-	rep(0,50000)

for(i in 1:50000){
	ith.us		<-	us.samp.exper[i,]
	PofThgUS[i]	<-	-Const.nll(s=s.experiment,us=ith.us,theta=theta.experiment)

	for(j in 1:100){
		
		PofThpgUS[i,j]<-	-Const.nll(s=s.experiment,us=ith.us,theta=theta.seq[j])
		
	}
	
}

rlnL.theta.p	<-	 PofThpgUS - PofThgUS

rL.theta		<-	exp(apply(rlnL.theta.p,2,mean))
crit.val		<-	exp(-qchisq(0.95,1)/2)
rL.g.crit.val	<-	which(rL.theta>crit.val)
theta.CI		<-	theta.seq[rL.g.crit.val[c(1,length(rL.g.crit.val))]]

# Now obtaining TMRCA samples from using theta CI
# Upper boundary
data.list			<-	list(n=n.experiment,s=s.experiment,theta=theta.CI[2])
jm.sample.exper.up	<-	jags.model(file="coalescent_const_kalman.txt",data=data.list,n.chains=1,n.adapt=1000)
out.sample.exper.up	<-	coda.samples(model=jm.sample.exper.up,variable.names="tmrca",n.iter=500000,thin=1)
tmrca.experiment.up	<-	median(out.sample.exper.up[[1]][,1])
Ne.experiment.up	<-	ngens.experiment/(tmrca.experiment.up)
mut.rate.up			<-	theta.CI[2]/(2*Ne.experiment.up)

# Lower boundary
data.list			<-	list(n=n.experiment,s=s.experiment,theta=theta.CI[1])
jm.sample.exper.lo	<-	jags.model(file="coalescent_const_kalman.txt",data=data.list,n.chains=1,n.adapt=1000)
out.sample.exper.lo	<-	coda.samples(model=jm.sample.exper.lo,variable.names="tmrca",n.iter=500000,thin=1)
tmrca.experiment.lo	<-	median(out.sample.exper.lo[[1]][,1])
Ne.experiment.lo	<-	ngens.experiment/(tmrca.experiment.lo)
mut.rate.lo			<-	theta.CI[1]/(2*Ne.experiment.lo)

# Theta, Mutation rate and Population size for the experiment with Confidence intervals
lab.results	<-	matrix(c(theta.CI[1],theta.experiment,theta.CI[2]
						,mut.rate.lo,mut.rate,mut.rate.up
						,Ne.experiment.lo,Ne.experiment,Ne.experiment.up)
						,ncol=3,nrow=3,dimnames=list(
						c("Theta","Mutation Rate","Ne"),c("2.5%","MLE","97.5%")),byrow=TRUE)

write.table(lab.results,"lab_results.txt",sep="\t",quote=FALSE)

##################################################################################
# Estimating the time to the most recent common ancestor assuming
# constant population size for each zebra
K	<-	70

const.estimation	<-	function(r){

	n.clons	<-	rep(zeb.only[r,1],K)
	s.clons	<-	rep(zeb.only[r,2],K)

	data.list	<-	list(n=n.clons,s=s.clons,K=K)

	params	<-	c("theta")

	jm		<-	jags.model(file="coalescent_const.txt",data=data.list
						,n.chains=2,n.adapt=10000)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=100000,thin=100)
	
	out
	
}

cl				<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("K","zeb.only"))
const.samples1	<-	clusterApply(cl,1:nrow(zeb.only),const.estimation)
stopCluster(cl)

theta.hat	<-	rep(0,nrow(zeb.only))

for(i in 1:length(theta.hat)){
	
	ith.zeb	<-	const.samples1[[i]]
	ith.sum	<-	summary(ith.zeb)
	theta.hat[i]	<-	ith.sum$statistics[1]
	
}

# Obtaining TMRCA
const.samples	<-	function(r){

	n	<-	zeb.only[r,1]
	s	<-	zeb.only[r,2]

	data.list	<-	list(n=n,s=s,theta=theta.hat[r])

	params	<-	c("tmrca")

	jm		<-	jags.model(file="coalescent_const_kalman.txt",data=data.list
						,n.chains=1,n.adapt=1000)

	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
	
	
}

cl				<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("theta.hat","zeb.only"))
const.kalman	<-	clusterApply(cl,1:nrow(zeb.only),const.samples)
stopCluster(cl)

Ne.const	<-	rep(0,nrow(zeb.only))
const.tmrca	<-	matrix(0,nrow=50000,ncol=nrow(zeb.only),dimnames=list(1:50000,rownames(zeb.only)))
const.tmrca1	<-	matrix(0,nrow=50000,ncol=nrow(zeb.only),dimnames=list(1:50000,rownames(zeb.only)))
const.tmrca.coal	<-	matrix(0,nrow=50000,ncol=nrow(zeb.only),dimnames=list(1:50000,rownames(zeb.only)))

for(i in 1:nrow(zeb.only)){
	ith.tmrca		<-	const.kalman[[i]][[1]][,1]
	const.tmrca.coal[,i]<-	ith.tmrca	
	Ne.const[i]		<-	theta.hat[i]/(2*mut.rate)
	ith.j			<-	ith.tmrca*Ne.const[i]
	ith.j1		<-	ith.tmrca*(Ne.experiment/2) #########MAKE WENDY AND RYAN'S CHANGE HERE!!!!!
	const.tmrca[,i]	<-	ith.j/6
	const.tmrca1[,i]	<-	ith.j1/6	
}

const.res.tab	<-	cbind(Theta=theta.hat,Ne=Ne.const
				,TMRCA=apply(const.tmrca,2,mean),TMRCA1=apply(const.tmrca1,2,mean))
write.table(const.res.tab,"constant_pop_results.txt",sep="\t",quote=FALSE)

##################################################################################
#				Estimation of time to most recent common ancestor 
#					assuming exponential population growth

K	<-	70

exp.estimation	<-	function(r){

	n.clons	<-	rep(zeb.only[r,1],K)
	s.clons	<-	rep(zeb.only[r,2],K)

	data.list	<-	list(n=n.clons,s=s.clons,K=K)

	params	<-	c("theta0","beta")

	jm		<-	jags.model(file="coalescent_mod.txt",data=data.list
						,n.chains=2,n.adapt=10000)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=100000,thin=100)
	
	out
	
}

cl	<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("K","zeb.only"))
exp.samples1	<-	clusterApply(cl,1:nrow(zeb.only),exp.estimation)
stopCluster(cl)

theta0.hat	<-	rep(0,nrow(zeb.only))
beta.hat	<-	rep(0,nrow(zeb.only))

for(i in 1:nrow(zeb.only)){
	
	ith.zeb	<-	exp.samples1[[i]]
	ith.sum	<-	summary(ith.zeb)
	theta0.hat[i]	<-	ith.sum$statistics[2,1]
	beta.hat[i]		<-	ith.sum$statistics[1,1]
	
}

# Obtaining Kalman estimates of TMRCA given beta hat and theta0 hat for the 
# exponential population growth model

exp.samples	<-	function(r){
	
	data.list	<-	list(theta0=theta0.hat[r],beta=beta.hat[r],n=zeb.only[r,1],s=zeb.only[r,2])
	
	params	<-	"tmrca"
	
	jm		<-	jags.model(file="coalescent_kalman.txt",data=data.list
						,n.chains=1,n.adapt=1000)

	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
		
}

cl	<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("zeb.only","theta0.hat","beta.hat"))
exp.kalman	<-	clusterApply(cl,1:nrow(zeb.only),exp.samples)
stopCluster(cl)

N0			<-	theta0.hat/(2*mut.rate)
N1 <- N1.1 <- exp.tmrca <- exp.tmrca.coal <- exp.tmrca1 <- matrix(0,nrow=50000,ncol=nrow(zeb.only),dimnames=list(1:50000,rownames(zeb.only)))

for(i in 1:nrow(zeb.only)){
	ith.tmrca		<-	exp.kalman[[i]][[1]][,1]
	exp.tmrca.coal[,i]	<-	ith.tmrca	
	N1[,i]			<-	N0[i]*exp(-beta.hat[i]*ith.tmrca)
	N1.1[,i]			<-	(Ne.experiment/2)*exp(-beta.hat[i]*ith.tmrca)   #########MAKE WENDY AND RYAN'S CHANGE HERE!!!!!
	ith.j				<-	j.transf(ith.tmrca,N0[i],beta.hat[i])
	ith.j1			<-	j.transf(ith.tmrca,Ne.experiment/2,beta.hat[i]) #########MAKE WENDY AND RYAN'S CHANGE HERE!!!!!
	exp.tmrca[,i]		<-	ith.j/6
	exp.tmrca1[,i]		<-	ith.j1/6

}

exp.res.tab	<-	cbind(Theta0=theta0.hat,beta=beta.hat,Ne=apply(N1,2,mean),Ne1=apply(N1.1,2,mean)
				,TMRCA=apply(exp.tmrca,2,mean),TMRCA1=apply(exp.tmrca1,2,mean))

write.table(exp.res.tab,"exponential_results.txt",sep="\t",quote=FALSE)
##################################################################################
# Perform likelihood Ratio test to select the most likely model between the
# constant population size and exponential population growth
# Obtaing Kalman estimates of us under the Exponential growth model

us.exp.sampling	<-	function(r){

	n	<-	zeb.only[r,1]
	s	<-	zeb.only[r,2]

	data.list	<-	list(n=n,s=s,beta=beta.hat[r],theta0=theta0.hat[r])

	params	<-	c("us.exp")

	jm		<-	jags.model(file="coalescent_kalman.txt",data=data.list
							,n.chains=1,n.adapt=1000)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
	
	out
	
}

cl	<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("zeb.only","beta.hat","theta0.hat"))
us.exp	<-	clusterApply(cl,1:nrow(zeb.only),us.exp.sampling)
stopCluster(cl)

n.samps	<-	nrow(us.exp[[1]][[1]])

exp.ll	<-	matrix(0,ncol=nrow(zeb.only),nrow=n.samps)
const.ll<-	matrix(0,ncol=nrow(zeb.only),nrow=n.samps)

for(j in 1:nrow(zeb.only)){
	jth.s		<-	zeb.only[j,2]
	jth.theta0	<-	theta0.hat[j]
	jth.beta	<-	beta.hat[j]
	jth.theta	<-	theta.hat[j]
	for(i in 1:n.samps){
		ith.us.exp	<-	us.exp[[j]][[1]][i,]
		ith.exp.ll	<-	-Exp.mut.nll(s=jth.s,us=ith.us.exp,theta.0=jth.theta0,beta=jth.beta)
		exp.ll[i,j]	<-	ith.exp.ll
		ith.const.ll<-	-Const.nll(s=jth.s,us=ith.us.exp,theta=jth.theta)	
		const.ll[i,j]<-	ith.const.ll

	}
}

lrt	<-	apply(-2*(const.ll-exp.ll),2,mean)

p.val	<-	1-pchisq(lrt,1)

##################################################################################
# Profile likelihood for the exponential model ONLY since it is a better fit to the
# data based on the likelihood ratio test

prof.lik	<-	function(r){
		
	s			<-	zeb.only[r,2]
	n		<-	zeb.only[r,1]
	nm1		<-	n-1
	theta0	<-	theta0.hat[r]
	beta	<-	beta.hat[r]
	theta0.seq	<-	seq(0.1,4,length=1000)
	beta.seq	<-	seq(0.1,3,length=1000)
	PofThB		<-	rep(0,100)
	PofThjB		<-	matrix(0,ncol=1000,nrow=50000)
	PofThBj		<-	matrix(0,ncol=1000,nrow=50000)

	for(i in 1:50000){
	
		ith.us		<-	us.exp[[r]][[1]][i,]
		PofThB[i]	<-	-Exp.mut.nll(s=s,us=ith.us,theta.0=theta0,beta=beta)	
		for(j in 1:1000){
			PofThjB[i,j]	<-	-Exp.mut.nll(s=s,us=ith.us,theta.0=theta0.seq[j],beta=beta)
			PofThBj[i,j]	<-	-Exp.mut.nll(s=s,us=ith.us,theta.0=theta0,beta=beta.seq[j])
		}
		
	}

	list(PofThB=PofThB,PofThjB=PofThjB,PofThBj=PofThBj)
}

cl		<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("zeb.only","beta.hat","theta0.hat","us.exp","Exp.mut.nll"))
prof.lik.samps	<-	clusterApply(cl,1:nrow(zeb.only),prof.lik)
stopCluster(cl)
theta0.seq	<-	seq(0.1,4,length=1000)
beta.seq	<-	seq(0.1,3,length=1000)

RL.theta0	<-	matrix(0,nrow=11,ncol=1000,dimnames=list(rownames(zeb.only),theta0.seq))
RL.beta	<-	matrix(0,nrow=11,ncol=1000,dimnames=list(rownames(zeb.only),beta.seq))

for(i in 1:nrow(zeb.only)){

	ith.PofThB		<-	matrix(rep(prof.lik.samps[[i]]$PofThB,1000),ncol=1000,nrow=50000,byrow=FALSE)
	ith.RL.theta	<-	prof.lik.samps[[i]]$PofThjB - ith.PofThB
	ith.RL.beta		<-	prof.lik.samps[[i]]$PofThBj - ith.PofThB
	
	RL.theta0[i,]	<-	exp(apply(ith.RL.theta,2,mean))
	RL.beta[i,]		<-	exp(apply(ith.RL.beta,2,mean))
	
}

##################################################################################
# Obtaining new estimates of Theta0 and Beta based on the likelihood profile

theta0.hat2	<- beta.hat2	<-	rep(0,11)

for(i in 1:11){
	theta0.hat2[i]	<-	theta0.seq[which.max(RL.theta0[i,])]
	beta.hat2[i]	<-	beta.seq[which.max(RL.beta[i,])]
}

# Rescaling the ML Estimates of Beta and Theta0 to the maximum of the likelihood profile

RL.theta2	<-	RL.theta0/apply(RL.theta0,1,max)
RL.beta2	<-	RL.beta/apply(RL.beta,1,max)

crit.val		<-	exp(-qchisq(0.95,1)/2)
theta0.CI		<-	beta.CI	<-	matrix(0,nrow=11,ncol=2,dimnames=list(rownames(zeb.only),c("2.5%","97.5%")))

for(i in 1:11){
	
	theta0.crit.val	<-	which(RL.theta2[i,]>crit.val)
	beta.crit.val	<-	which(RL.beta2[i,]>crit.val)
	theta0.CI[i,]	<-	theta0.seq[theta0.crit.val[c(1,length(theta0.crit.val))]]
	beta.CI[i,]		<-	beta.seq[beta.crit.val[c(1,length(beta.crit.val))]]
	
}

# Obtaining Kalman estimates of TMRCA given beta hat and theta0 hat for the 
# exponential population growth model. These resutls are given by  the new 
# Theta0 and Beta from the profile likelihood

exp.samples	<-	function(r){
	
	data.list	<-	list(theta0=theta0.hat2[r],beta=beta.hat2[r],n=zeb.only[r,1],s=zeb.only[r,2])
	
	params	<-	"tmrca"
	
	jm		<-	jags.model(file="coalescent_kalman.txt",data=data.list
						,n.chains=1,n.adapt=1000)

	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
		
}

cl	<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("zeb.only","theta0.hat2","beta.hat2"))
exp.kalman	<-	clusterApply(cl,1:nrow(zeb.only),exp.samples)
stopCluster(cl)

N0			<-	theta0.hat2/(2*mut.rate)
N1 <- N1.1 <- exp.tmrca <- exp.tmrca.coal <- exp.tmrca1 <- matrix(0,nrow=50000,ncol=nrow(zeb.only),dimnames=list(1:50000,rownames(zeb.only)))

for(i in 1:nrow(zeb.only)){
	ith.tmrca		<-	exp.kalman[[i]][[1]][,1]
	exp.tmrca.coal[,i]	<-	ith.tmrca	
	N1[,i]			<-	N0[i]*exp(-beta.hat2[i]*ith.tmrca)
	N1.1[,i]			<-	(Ne.experiment/2)*exp(-beta.hat2[i]*ith.tmrca)
	ith.j				<-	j.transf(ith.tmrca,N0[i],beta.hat2[i])
	ith.j1			<-	j.transf(ith.tmrca,Ne.experiment/2,beta.hat2[i])
	exp.tmrca[,i]		<-	ith.j/6
	exp.tmrca1[,i]		<-	ith.j1/6

}

exp.res.tab	<-	cbind(Theta0=theta0.hat2,beta=beta.hat2,Ne=apply(N1,2,mean),Ne1=apply(N1.1,2,mean)
				,TMRCA=apply(exp.tmrca,2,mean),TMRCA1=apply(exp.tmrca1,2,mean))
				
write.table(exp.res.tab,"exponential_results.txt",sep="\t",quote=FALSE)

##################################################################################
# Perform likelihood Ratio test to select the most likely model between the
# constant population size and exponential population growth
# Obtaing Kalman estimates of us under the Exponential growth model
# This section takes samples of Us given the theta0 and beta hats from the
# profile likelihood

us.exp.sampling	<-	function(r){

	n	<-	zeb.only[r,1]
	s	<-	zeb.only[r,2]

	data.list	<-	list(n=n,s=s,beta=beta.hat2[r],theta0=theta0.hat2[r])

	params	<-	c("us.exp")

	jm		<-	jags.model(file="coalescent_kalman.txt",data=data.list
							,n.chains=1,n.adapt=1000)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
	
	out
	
}

cl	<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("zeb.only","beta.hat2","theta0.hat2"))
us.exp	<-	clusterApply(cl,1:nrow(zeb.only),us.exp.sampling)
stopCluster(cl)

n.samps	<-	nrow(us.exp[[1]][[1]])

exp.ll	<-	matrix(0,ncol=nrow(zeb.only),nrow=n.samps)
const.ll<-	matrix(0,ncol=nrow(zeb.only),nrow=n.samps)

for(j in 1:nrow(zeb.only)){
	jth.s		<-	zeb.only[j,2]
	jth.theta0	<-	theta0.hat2[j]
	jth.beta	<-	beta.hat2[j]
	jth.theta	<-	theta.hat[j]
	for(i in 1:n.samps){
		ith.us.exp	<-	us.exp[[j]][[1]][i,]
		ith.exp.ll	<-	-Exp.mut.nll(s=jth.s,us=ith.us.exp,theta.0=jth.theta0,beta=jth.beta)
		exp.ll[i,j]	<-	ith.exp.ll
		ith.const.ll<-	-Const.nll(s=jth.s,us=ith.us.exp,theta=jth.theta)	
		const.ll[i,j]<-	ith.const.ll

	}
}

lrt	<-	apply(-2*(const.ll-exp.ll),2,mean)

p.val	<-	1-pchisq(lrt,1)

#####################################################################
# Obtaining confidence intervals for Ne and TMRCA assuming exponential 
# population growth
# Lower bound

exp.samples.lo	<-	function(r){
	
	data.list	<-	list(theta0=theta0.CI[r,1],beta=beta.CI[r,2],n=zeb.only[r,1],s=zeb.only[r,2])
	
	params	<-	"tmrca"
	
	jm		<-	jags.model(file="coalescent_kalman.txt",data=data.list
						,n.chains=1,n.adapt=1000)

	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
		
}

cl	<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("zeb.only","beta.CI","theta0.CI"))
exp.kalman.lo	<-	clusterApply(cl,1:nrow(zeb.only),exp.samples.lo)
stopCluster(cl)

N0.lo		<-	theta0.CI[,1]/(2*mut.rate)
N1.lo <- N1.1.lo <- exp.tmrca.lo <- exp.tmrca.coal.lo <- exp.tmrca1.lo <- matrix(0,nrow=50000,ncol=nrow(zeb.only),dimnames=list(1:50000,rownames(zeb.only)))

for(i in 1:nrow(zeb.only)){
	ith.tmrca		<-	exp.kalman.lo[[i]][[1]][,1]
	exp.tmrca.coal.lo[,i]	<-	ith.tmrca	
	N1.lo[,i]			<-	N0.lo[i]*exp(-beta.CI[i,2]*ith.tmrca)
	N1.1.lo[,i]			<-	(Ne.experiment/2)*exp(-beta.CI[i,2]*ith.tmrca)
	ith.j				<-	j.transf(ith.tmrca,N0.lo[i],beta.CI[i,2])
	ith.j1				<-	j.transf(ith.tmrca,Ne.experiment/2,beta.CI[i,2])
	exp.tmrca.lo[,i]		<-	ith.j/6
	exp.tmrca1.lo[,i]		<-	ith.j1/6

}


# Upper Bound
exp.samples.hi	<-	function(r){
	
	data.list	<-	list(theta0=theta0.CI[r,2],beta=beta.CI[r,1],n=zeb.only[r,1],s=zeb.only[r,2])
	
	params	<-	"tmrca"
	
	jm		<-	jags.model(file="coalescent_kalman.txt",data=data.list
						,n.chains=1,n.adapt=1000)

	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
		
}

cl	<-	makeCluster(nrow(zeb.only),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("zeb.only","beta.CI","theta0.CI"))
exp.kalman.hi	<-	clusterApply(cl,1:nrow(zeb.only),exp.samples.hi)
stopCluster(cl)

N0.hi		<-	theta0.CI[,2]/(2*mut.rate)
N1.hi <- N1.1.hi <- exp.tmrca.hi <- exp.tmrca.coal.hi <- exp.tmrca1.hi <- matrix(0,nrow=50000,ncol=nrow(zeb.only),dimnames=list(1:50000,rownames(zeb.only)))

for(i in 1:nrow(zeb.only)){
	ith.tmrca		<-	exp.kalman.hi[[i]][[1]][,1]
	exp.tmrca.coal.hi[,i]	<-	ith.tmrca	
	N1.hi[,i]			<-	N0.hi[i]*exp(-beta.CI[i,1]*ith.tmrca)
	N1.1.hi[,i]			<-	(Ne.experiment/2)*exp(-beta.CI[i,1]*ith.tmrca)
	ith.j				<-	j.transf(ith.tmrca,N0.hi[i],beta.CI[i,1])
	ith.j1				<-	j.transf(ith.tmrca,Ne.experiment/2,beta.CI[i,1])
	exp.tmrca.hi[,i]		<-	ith.j/6
	exp.tmrca1.hi[,i]		<-	ith.j1/6

}

exp.res.tab.CI			<-	data.frame(Theta0=rep(0,11))	
exp.res.tab.CI$Theta0	<-	paste0(round(theta0.hat2,2),"(",round(theta0.CI[,1],2),",",round(theta0.CI[,2],2),")")
exp.res.tab.CI$Beta		<-	paste0(round(beta.hat2,2),"(",round(beta.CI[,1],2),",",round(beta.CI[,2],2),")")
exp.res.tab.CI$Ne		<-	paste0(round(apply(N1,2,mean),2),"(",round(apply(N1.lo,2,mean),2),",",round(apply(N1.hi,2,mean),2),")")
exp.res.tab.CI$Ne1		<-	paste0(round(apply(N1.1,2,mean),2),"(",round(apply(N1.1.lo,2,mean),2),",",round(apply(N1.1.hi,2,mean),2),")")
exp.res.tab.CI$TMRCA	<-	paste0(round(apply(exp.tmrca,2,mean),2),"(",round(apply(exp.tmrca.lo,2,mean),2)
									,",",round(apply(exp.tmrca.hi,2,mean),2),")")
exp.res.tab.CI$TMRCA1	<-	paste0(round(apply(exp.tmrca1,2,mean),2),"(",round(apply(exp.tmrca1.lo,2,mean),2)
									,",",round(apply(exp.tmrca1.hi,2,mean),2),")")

write.table(exp.res.tab.CI,"exponential_results.txt",sep="\t",quote=FALSE)

#####################################################################
# Since the output is so big I will only save the results of the estimations
# and likelihood profiles.

objects.save<-c("out.experiment","rL.theta","const.samples1","exp.samples1","RL.theta0","RL.beta")
save(list=objects.save,file="Zebras_coalescent_results.RData")





