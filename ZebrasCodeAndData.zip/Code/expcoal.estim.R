# Running t-walk with Data Cloning

# theta0.init = vector of length 2 one for each chain
# beta.init	= vector of length 2 one for each chain
# out is a list of an mcmc.list with the posterior distributions of the parameters and 
# the stats from the output of the Runtwalk function

expcoal.estim	<-	function(n,nsegreg,nclones,theta0.init,beta.init,niters,burn.in=NULL,lag=NULL,frac2burn=NULL,PlotObj=FALSE
							,PlotLogPost=FALSE,plot.res=FALSE){
	
	if(length(theta0.init)!=2|length(beta.init)!=2){stop("Specify two values of theta0 and beta one for each chain")}
	if(is.null(burn.in)&is.null(frac2burn)){stop("Specify either the number of iterations or a proportion of the total iterations to discard")}
	
	#### Data organization section
	tmp.tree1	<-	rcoal.exp(n=n,beta=beta.init[1],compare=FALSE,with.mut=FALSE,theta.0=theta0.init[1])
	tmp.tree2	<-	rcoal.exp(n=n,beta=beta.init[2],compare=FALSE,with.mut=FALSE,theta.0=theta0.init[2])
	us1			<-	us.calc(tmp.tree1)
	us2			<-	us.calc(tmp.tree2)
	nclons		<-	nclones
	x0			<-	c(theta0.init[1],beta.init[1],rep(us1,nclons))
	x0prime		<-	c(theta0.init[2],beta.init[2],rep(us2,nclons))
	
	s			<<-	nsegreg
	dim.parms	<<-	length(x0)
	
	DC.run		<-	Runtwalk(Tr=niters,dim=dim.parms,Obj=Exp.post.DC,Supp=Exp.Supp,x0=x0,xp0=x0prime
							,PlotObj=PlotObj,PlotLogPost=PlotLogPost)
	if(is.null(burn.in)){burn.in	<-	niters*frac.2burn}

	
	DC.chain1		<-	mcmc(DC.run$output[,1:2],start=burn.in,end=niters,thin=lag)
	DC.chain2		<-	mcmc(DC.run$outputp[,1:2],start=burn.in,end=niters,thin=lag)
	colnames(DC.chain1)	<-	colnames(DC.chain2)	<-	c("theta0","beta")
	mcmc.out		<-	mcmc.list(DC.chain1,DC.chain2)
	stats.out		<-	list(n=DC.run$n,Tr=DC.run$Tr,Us=DC.run$Us,Ups=DC.run$Ups)
	run.pars		<-	c(Clones=nclones,burn.in=burn.in,lag=lag,frac2burn=frac2burn,theta0.init=theta0.init,beta.init=beta.init)
	
	out			<-	list(mcmc.samples=mcmc.out,mcmc.stats=stats.out,run.pars=run.pars)
	
	if(plot.res){
		
		#hats
		hats	<-	summary(mcmc.out)$statistics
		theta.0.hat	<-	hats[1,1]
		beta.hat	<-	hats[2,2]
		thinning	<-	seq(from=burn.in,to=niters,by=lag)
		chain1		<-	as.matrix(DC.chain1)
		chain2		<-	as.matrix(DC.chain2)
		
		par(mfrow=c(5,2),mar=c(3.5,3.5,2,1),oma=c(1,1,2.5,1),mgp=c(2.25,0.75,0))
		# Chain1: theta0
		hist(chain1[,1],main=expression(paste("Posterior distribution of ",theta[0])))
		abline(v=theta.0.hat, col="red", lwd=2)

		# Chain2: theta0
		hist(chain2[,1],main=expression(paste("Posterior distribution of ",theta[0])))
		abline(v=theta.0.hat, col="red", lwd=2)
		
		# Chain1: beta
		hist(chain1[,2],main=expression(paste("Posterior distribution of ",beta)))
		abline(v=beta.hat, col="red", lwd=2)
		
		# Chain2: beta
		hist(chain2[,2],main=expression(paste("Posterior distribution of ",beta)))
		abline(v=beta.hat, col="red", lwd=2)
		
		# Chain 1 theta		
		plot(chain1[,1], type="l",bty="l",xlab="Sample",ylab=expression(theta[0]))
		# Chain 2 theta
		plot(chain2[,1], type="l",bty="l",xlab="Sample",ylab=expression(theta[0]))

		# Chain 1 beta
		plot(chain1[,2], type="l",bty="l",xlab="Sample",ylab=expression(beta))
		# Chain 2 beta
		plot(chain2[,2], type="l",bty="l",xlab="Sample",ylab=expression(beta))
		
		# Chain 1 nll
		plot(stats.out$Us[thinning], type="l",xlab="Sample",ylab="Negative Log Likelihood",bty="l")
		# Chain 2 nll
		plot(stats.out$Ups[thinning], type="l",xlab="Sample",ylab="Negative Log Likelihood",bty="l")
		
		mtext("Chain 1",outer=TRUE,at=0.25)
		mtext("Chain 2",outer=TRUE,at=0.75)
		
	}
	
	return(out)
	
}


plot.expcoalres	<-	function(obj){
	
	#hats
		hats	<-	summary(obj$mcmc.samples)$statistics
		theta.0.hat	<-	hats[1,1]
		beta.hat	<-	hats[2,2]
		burn.in		<-	obj$run.pars$burn.in
		if(is.null(burn.in)){burn.in	<-	obj$run.pars$niters*obj$run.pars$frac2burn}
		thinning	<-	seq(from=burn.in,to=niters,by=lag)
		chain1		<-	as.matrix(obj$mcmc.samples[[1]])
		chain2		<-	as.matrix(obj$mcmc.samples[[1]])
		
		par(mfrow=c(5,2),mar=c(3.5,3.5,2,1),oma=c(1,1,2.5,1),mgp=c(2.25,0.75,0))
		# Chain1: theta0
		hist(chain1[,1],main=expression(paste("Posterior distribution of ",theta[0])))
		abline(v=theta.0.hat, col="red", lwd=2)

		# Chain2: theta0
		hist(chain2[,1],main=expression(paste("Posterior distribution of ",theta[0])))
		abline(v=theta.0.hat, col="red", lwd=2)
		
		# Chain1: beta
		hist(chain1[,2],main=expression(paste("Posterior distribution of ",beta)))
		abline(v=beta.hat, col="red", lwd=2)
		
		# Chain2: beta
		hist(chain2[,2],main=expression(paste("Posterior distribution of ",beta)))
		abline(v=beta.hat, col="red", lwd=2)
		
		# Chain 1 theta		
		plot(chain1[,1], type="l",bty="l",xlab="Sample",ylab=expression(theta[0]))
		# Chain 2 theta
		plot(chain2[,1], type="l",bty="l",xlab="Sample",ylab=expression(theta[0]))

		# Chain 1 beta
		plot(chain1[,2], type="l",bty="l",xlab="Sample",ylab=expression(beta))
		# Chain 2 beta
		plot(chain2[,2], type="l",bty="l",xlab="Sample",ylab=expression(beta))
		
		# Chain 1 nll
		plot(stats.out$Us[thinning], type="l",xlab="Sample",ylab="Negative Log Likelihood",bty="l")
		# Chain 2 nll
		plot(stats.out$Ups[thinning], type="l",xlab="Sample",ylab="Negative Log Likelihood",bty="l")
		
		mtext("Chain 1",outer=TRUE,at=0.25)
		mtext("Chain 2",outer=TRUE,at=0.75)
		
	}

	
	
}

#### Testing expcoal.estim.function
theta0.init <- c(0.1,0.1+0.3)
beta.init 	<- c(0.1,0.1*0.7)
n			<- 29
nsegreg		<-	4
nclones		<-	2
niters		<-	10000
frac.2burn	<-	0.1
lag			<-	10

DC.estim	<-	expcoal.estim(n=n,nsegreg=nsegreg,nclones=nclones,theta0.init=theta0.init,beta.init=beta.init,niters=niters,lag=lag
								,frac2burn=frac.2burn,plot.res=TRUE)