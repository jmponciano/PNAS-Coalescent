library(ape)
#library(coalescentMCMC)
#library(Rtwalk)

# First things first:  plot a labeled tree and use the notation in this plot
# as the notation in ALL functions.
# Plot and print to understand all the notation used in the functions in this file

labeled.tree <- function(my.path="~/Desktop/tree_sample.tiff"){

	# Plot of a cladogram with 7 tips showing all of the variables
	tiff(my.path,width=11,height=8.5,units="in",res=300,compression="lzw",type="cairo",family="times")
	n	<-	7
	beta<-	20
	cex.txt	<-	2
	set.seed(456)
	tmp	<-	rcoal.exp(n,beta)
	my.brtimes	<-	branching.times(tmp)
	plot.brtimes<-	c(max(my.brtimes)-my.brtimes,max(my.brtimes))
	us			<-	us.calc(tmp)
	par(oma=c(3,1,3,1))
	plot(tmp,no.margin=TRUE,type="cladogram",show.tip.label=FALSE,edge.width=2)
	abline(v=plot.brtimes,lty=2,col="red",lwd=2)
	axis(1,at=plot.brtimes,labels=expression(t[1],t[2],t[3],t[4],t[5],t[6],t[7]==0),cex.axis=cex.txt)
	axis(3,at=plot.brtimes, labels=expression(theta[1], theta[2], theta[3], theta[4], theta[5], theta[6], 	
	theta[0]), lwd=0, cex.axis=cex.txt)
	axis(1,at=plot.brtimes[1:(n-1)]+us/2,labels=expression(u[2], u[3], u[4], u[5], u[6], u[7]), lwd=0, 
	line=-0.5, cex.axis=cex.txt)
	axis(4,at=1:7,labels=1:7,lwd=0,mgp=c(0,-2.5,0),las=2,cex.axis=cex.txt)
	dev.off()
}


branching.times.inv<- function(brtimes, phy){
	
	
	# add zero ages for the tips
	# Note: n.branches= n.tips + n.nodes
	#       of course, Nnode(phy) = length(brtimes) 
	allAges <- c(rep(0,Ntip(phy)), brtimes)   
	
	# get parental node age for each edge
	parent.Ages <- allAges[phy$edge[,1]]
	
	# get child node edges
	child.Ages <- allAges[phy$edge[,2]]
	
	# Calc edge lengths:
	new.edge.len <- parent.Ages-child.Ages
	
	# Now subs. into original tree the new edge lengths
	
	phy$edge.length <- new.edge.len
	
	return(phy)
}



exp.branching.times<- function(phy, beta){
		
	# add zero ages for the tips
	# Note: n.branches= n.tips + n.nodes
	#       of course, Nnode(phy) = length(brtimes)
	old.brtimes <- branching.times(phy)
	nbrtimes <- length(old.brtimes)
	us <- old.brtimes-c(old.brtimes[2:nbrtimes],0) 
	exp.us <- (exp(-us*beta)-1)/(-beta)
	new.brtimes <- rep(0,nbrtimes)
	for(i in 1:nbrtimes){new.brtimes[i] <- sum(exp.us[i:nbrtimes])}
	names(new.brtimes) <- names(old.brtimes)
	 
	allAges <- c(rep(0,Ntip(phy)), new.brtimes)   
	
	# get parental node age for each edge
	parent.Ages <- allAges[phy$edge[,1]]
	
	# get child node edges
	child.Ages <- allAges[phy$edge[,2]]
	
	# Calc edge lengths:
	new.edge.len <- (parent.Ages-child.Ages)
	
	# Now subs. into original tree the new edge lengths
	
	phy$edge.length <- new.edge.len
	
	return(phy)
}

us.calc <- function(phy){
	
	#function to compute the inter-coalescence times
	brtimes <- branching.times(phy)
	nbrtimes <- length(brtimes)
	us <- brtimes-c(brtimes[2:nbrtimes],0) 
	
	return(us)
	
}

rcoal.exp<- function(n, beta,compare=FALSE,with.mut=FALSE, theta.0=NULL){
	
	# Use the 'compare' option to see how branch lengths compare
	# when theta decays exponentially to the past with 
	# the case when theta is constant.
	# If with.mut=TRUE, you need to specify a non-null value of theta.0
	
	tmp <- rcoal(n=n)
	tmp2 <- exp.branching.times(phy=tmp, beta=beta)
	
	if(compare){out.phy <- c.phylo(cstN.tree=tmp, exp.tree=tmp2)
		
		}else{out.phy <- tmp2}
		
	if(with.mut){
		
		if(is.null(theta.0)){stop("theta.0 is null")}
		
		# Generate mutations
		t1.2tnm1 <- branching.times(tmp2)
		nm1      <- n-1
		thetas  <- theta.0*exp(-beta*t1.2tnm1)
		us     	<- us.calc(tmp2)
		theta   <- sum(thetas*us)
		L       <- sum(us*(2:n))
		lam     <- (theta*L)/2
		n.segreg<- rpois(n=1,lambda=lam)	
		
		out <- list(phy = out.phy, n.segreg=n.segreg)
		
	}else{out <- out.phy}
	
	return(out)
	
}


Exp.Supp <- function(params){
	
	beta <- params[1]
	us  <- params[2:length(params)]
	us.max	<-	max(us)

	exp.test    <- is.finite(exp(us.max*beta))
	finite.test <- all(is.finite(params))
	beta.test   <- (beta>0)#*(beta<1000)
	us.test	    <- (us>0)#*(us<4)

	return(all(c(finite.test,beta.test, us.test,exp.test)>0))	
	
}

Exp.negll <- function(theta.0,beta, br.times){
	
	# KEY:
	# br.times have to be c(branching.times(phy),0)
	# order of br.times: t.n, t.(n-1), t.(n-2),...,t2,t1=TMRCA
	
	ltheta.0 <- log(theta.0);
	ln2      <- log(2);
	n <- length(br.times)
	lncombs <-  lchoose(n=(2:n), 2);
	ncombs   <- exp(lncombs)
	tkm1s   <- br.times[-n]
	tks     <- br.times[-1]
	lnLv    <- lncombs + ln2 + beta*tkm1s-ltheta.0 
			-2*(ncombs/(theta.0*beta))*(exp(beta*tkm1s)-exp(beta*tks))
	negll   <- -sum(lnLv)  
	#if(!is.finite(negll)){negll <- 999999}
	return(negll)
	
}


Exp.mut.nll	<-	function(s=s,us,theta.0,beta){

	# us = u2,u3,...,un; length(us)=n-1;
	ltheta.0 <- log(theta.0);
	ln2      <- log(2);
	nm1 <- length(us);
	n   <- nm1+1;
	lncombs <-  lchoose(n=(2:n), 2);
	ncombs   <- exp(lncombs)
	my.brtimes	<-	rep(0,n)
	for(i in 1:nm1){my.brtimes[i] <- sum(us[i:nm1])}
	names(my.brtimes)	<-	paste0("t",1:n)
	tkm1s   <- my.brtimes[-n]
	tks     <- my.brtimes[-1]
	thetas	<-	theta.0*exp(-beta*my.brtimes)
	names(thetas)	<-	c(paste0("theta",1:nm1),"theta0")
	theta	<-	sum(thetas[1:nm1]*us)
	L		<-	sum(us*2:n)
	lambda	<-	theta*L*0.5
	neg.ll.1 <- -dpois(s,lambda,log=TRUE)
	neg.ll.2 <- -sum(lncombs + ln2 + beta*tkm1s-ltheta.0 
			-2*(ncombs/(theta.0*beta))*(exp(beta*tkm1s)-exp(beta*tks)))
	neg.ll	<-	neg.ll.1 + neg.ll.2
	return(neg.ll)

}

Exp.prior <- function(theta.0,beta, pdf="uniform"){
	
	switch(pdf,
	
			uniform = {ln.prior <- 0},
			
			lnorm  = {
					
				# prior for beta
				sigsq.x <- 0.1;
				mu.x <- log(0.01)-sigsq.x/2;
				beta.prior <- dlnorm(x=beta,meanlog=sigsq.x, sdlog=sqrt(sigsq.x), log=TRUE);
				ln.prior <- beta.prior;				
			}
			
	)
	return(ln.prior)
}


Exp.post <- function(params){
	
	len.parms <- length(params);
	#nm1 <- len.parms-2;
	#n   <- nm1+1;
	#theta.0 <- params[1];
	beta    <- params[1]
	# us = u2,u3,...,un; length(us)=n-1;
	us   <- params[2:len.parms] # length= n-1
	# If prior different than uniform, add the neg log prior 
	# for theta.0 and beta right here 

	nl.prior <- Exp.prior(theta.0=theta.0,beta=beta, pdf=prior.pdf)
	nlpost	<-	Exp.mut.nll(s=s,us=us,theta.0=theta.0,beta=beta) - nl.prior
	
	return(nlpost)
	
}


Exp.post.DC <- function(params){
	
	len.parms <- length(params);
	nm1 <- len.parms-1;
	n   <- nm1+1;
	#theta.0 <- params[1];
	beta    <- params[1]

	# If prior different than uniform, add the neg log prior 
	# for theta.0 and beta here (only once, not 'k' times!)
	nl.prior <- Exp.prior(theta.0=theta.0,beta=beta, pdf=prior.pdf)
	
	kus	<-	matrix(params[2:len.parms],ncol=nm1,byrow=TRUE)
	nclones <- nrow(kus)
	knlls  <- rep(0,nclones)
	for(i in 1:nclones){
		ith.us <- kus[i,]
		knlls[i] <- Exp.mut.nll(s=s, us=ith.us,theta.0=theta.0,beta=beta) 
	}

	tot.nlpost <- sum(knlls) - nl.prior
	return(tot.nlpost)
}

Const.nll	<-	function(s,us,theta){
	
	nm1		<-	length(us)
	n		<-	nm1 + 1
	L		<-	sum(us*2:n)
	lambda	<-	theta*L*0.5
	neg.ll.1 <- -dpois(s,lambda,log=TRUE)
	rate	<-	(2:n*((2:n)-1))/2
	neg.ll.2<-	rep(0,nm1)
	for(i in 1:nm1){
		
		neg.ll.2	<-	-dexp(us[i],rate[i],log=TRUE)
		
		
	}
	neg.ll	<-	neg.ll.1 + sum(neg.ll.2)
	return(neg.ll)
	
}

# Running t-walk with Data Cloning

# theta0 = the value of theta0
# beta.init	= vector of length 2 one for each chain
# out is a list of an mcmc.list with the posterior distributions of the parameters and 
# the stats from the output of the Runtwalk function

expcoal.estim	<-	function(n,nsegreg,nclones,theta0,beta.init,niters, prior.pdf="uniform", burn.in=NULL, 
							lag=NULL, frac2burn=NULL, plot.res=FALSE){
	
	if(length(beta.init)!=2){
		stop("Specify two values of beta one for each chain")}
	if(is.null(burn.in)&is.null(frac2burn)){
		stop("Specify either the number of iterations or a proportion of the total iterations to discard")}
	
	#### Data organization section
	tmp.tree1	<-	rcoal.exp(n=n,beta=beta.init[1],compare=FALSE,with.mut=FALSE,theta.0=theta0)
	tmp.tree2	<-	rcoal.exp(n=n,beta=beta.init[2],compare=FALSE,with.mut=FALSE,theta.0=theta0)
	us1			<-	us.calc(tmp.tree1)
	us2			<-	us.calc(tmp.tree2)
	nclons		<-	nclones
	x0			<-	c(beta.init[1],rep(us1,nclons))
	x0prime		<-	c(beta.init[2],rep(us2,nclons))
	
	s			<<-	nsegreg
	theta.0		<<-	theta0
	dim.parms	<<-	length(x0)
	prior.pdf   <<- prior.pdf
	
	DC.run		<-	Runtwalk(Tr=niters,dim=dim.parms,Obj=Exp.post.DC,Supp=Exp.Supp,x0=x0,xp0=x0prime
							,PlotObj=FALSE,PlotLogPost=FALSE)
	
	if(is.null(burn.in)){burn.in	<-	niters*frac2burn}
	
	DC.chain1		<-	mcmc(DC.run$output,start=burn.in,end=niters,thin=lag)
	DC.chain2		<-	mcmc(DC.run$outputp,start=burn.in,end=niters,thin=lag)
	#colnames(DC.chain1)	<-	colnames(DC.chain2)	<-	"beta"
	mcmc.out		<-	mcmc.list(DC.chain1,DC.chain2)
	stats.out		<-	list(n=DC.run$n,Tr=DC.run$Tr,Us=DC.run$Us,Ups=DC.run$Ups)
	run.pars		<-	c(Clones=nclones,burn.in=burn.in,lag=lag,frac2burn=frac2burn,theta0=theta0,beta.init=beta.init)
	
	out			<-	list(mcmc.samples=mcmc.out,mcmc.stats=stats.out,run.pars=run.pars)
	
	if(plot.res){
		
		#hats
		hats	<-	summary(mcmc.out)$statistics
		beta.hat	<-	hats[1,1]
		thinning	<-	seq(from=burn.in,to=niters,by=lag)
		chain1		<-	as.matrix(DC.chain1)
		chain2		<-	as.matrix(DC.chain2)
		
		par(mfrow=c(3,2),mar=c(3.5,3.5,2,1),oma=c(1,1,2.5,1),mgp=c(2.25,0.75,0))
		# Chain1: beta
		hist(chain1[,1],main=expression(paste("Posterior distribution of ",beta)))
		abline(v=beta.hat, col="red", lwd=2)
		
		# Chain2: beta
		hist(chain2[,1],main=expression(paste("Posterior distribution of ",beta)))
		abline(v=beta.hat, col="red", lwd=2)
		
		# Chain 1 beta
		plot(chain1[,1], type="l",bty="l",xlab="Sample",ylab=expression(beta))
		# Chain 2 beta
		plot(chain2[,1], type="l",bty="l",xlab="Sample",ylab=expression(beta))
		
		# Chain 1 nll
		plot(stats.out$Us[thinning], type="l",xlab="Sample",ylab="Negative Log Posterior",bty="l")
		# Chain 2 nll
		plot(stats.out$Ups[thinning], type="l",xlab="Sample",ylab="Negative Log Posterior",bty="l")
		
		mtext("Chain 1",outer=TRUE,at=0.25)
		mtext("Chain 2",outer=TRUE,at=0.75)
		
	}
	
	return(out)
	
}


plot.expcoalres	<-	function(obj){
	
	    #hats
		hats	<-	summary(obj$mcmc.samples)$statistics
		theta.0.hat	<-	hats[1,1]
		beta.hat	<-	hats[2,2]
		burn.in		<-	obj$run.pars$burn.in
		if(is.null(burn.in)){burn.in	<-	obj$run.pars$niters*obj$run.pars$frac2burn}
		thinning	<-	seq(from=burn.in,to=niters,by=lag)
		chain1		<-	as.matrix(obj$mcmc.samples[[1]])
		chain2		<-	as.matrix(obj$mcmc.samples[[1]])
		
		par(mfrow=c(5,2),mar=c(3.5,3.5,2,1),oma=c(1,1,2.5,1),mgp=c(2.25,0.75,0))
		# Chain1: theta0
		hist(chain1[,1],main=expression(paste("Posterior distribution of ",theta[0])))
		abline(v=theta.0.hat, col="red", lwd=2)

		# Chain2: theta0
		hist(chain2[,1],main=expression(paste("Posterior distribution of ",theta[0])))
		abline(v=theta.0.hat, col="red", lwd=2)
		
		# Chain1: beta
		hist(chain1[,2],main=expression(paste("Posterior distribution of ",beta)))
		abline(v=beta.hat, col="red", lwd=2)
		
		# Chain2: beta
		hist(chain2[,2],main=expression(paste("Posterior distribution of ",beta)))
		abline(v=beta.hat, col="red", lwd=2)
		
		# Chain 1 theta		
		plot(chain1[,1], type="l",bty="l",xlab="Sample",ylab=expression(theta[0]))
		# Chain 2 theta
		plot(chain2[,1], type="l",bty="l",xlab="Sample",ylab=expression(theta[0]))

		# Chain 1 beta
		plot(chain1[,2], type="l",bty="l",xlab="Sample",ylab=expression(beta))
		# Chain 2 beta
		plot(chain2[,2], type="l",bty="l",xlab="Sample",ylab=expression(beta))
		
		# Chain 1 nll
		plot(stats.out$Us[thinning], type="l",xlab="Sample",ylab="Negative Log Likelihood",bty="l")
		# Chain 2 nll
		plot(stats.out$Ups[thinning], type="l",xlab="Sample",ylab="Negative Log Likelihood",bty="l")
		
		mtext("Chain 1",outer=TRUE,at=0.25)
		mtext("Chain 2",outer=TRUE,at=0.75)
		
}


