library(coda)
# Function to run the coalescent MCMC
# n = Number of Individuals
# M	= Number of MCMC iterations
# ss = Number of segregating Sites
# theta = 2Ne(mu)

MH.coal	<-	function(n,M,ss,theta){

	nm1   <- n-1;

	Xv    <- 2:n;
	Tv    <- 2/(Xv*(Xv - 1));
	L     <- sum(Xv*Tv);


	T.mat <- matrix(rep(0,(nm1*M)),nrow=M,ncol=nm1);
	T.mat[1,] <- Tv;

	Uvect    <- runif(M);
	Tmrcav   <- rep(0,M);
	Tmrcav[1]<- sum(Tv);

	for (i in 2:M){
		#Step 1:
 	       	im1     <- i-1;
 	   	    old.Tv  <- T.mat[im1,]
	        XT      <- rep(0,nm1);
        	for(k in 1:nm1){XT[k] <- old.Tv[k]*Xv[k]}
    	    old.L   <- sum(XT); 

		#Step 2:
	        probs.samp <- rep(0,nm1);
			for (j in 1:nm1){probs.samp[j]<- (Xv[j]*old.Tv[j])/old.L};

			#x <- randX(1,xis=(2:n),probs = probs.samp)
			x          <- sample((2:n),size=1,prob=probs.samp) 
			x.ind      <- x-1;
			rate       <- (x*(x-1))/2;
			Tprimex    <- rexp(1,rate);
			Tx         <- old.Tv[x.ind];
			prop.Tv    <- old.Tv;
			prop.Tv[x.ind] <- Tprimex;
    	    XTprime    <- rep(0,nm1);
	        for(h in 1:nm1){XTprime[h] <- prop.Tv[h]*Xv[h]}
        	Lprime     <- sum(XTprime);

    	    #print(list(oTV = old.Tv,oL = old.L, soL = sum(old.Tv),pTV = prop.Tv, pL =Lprime,spl= sum(prop.Tv)))

	#Step 3: The Metropolis Algorithm:
			A <- min(1,((exp((0.5*theta)*(-Lprime+old.L)))*((Lprime/old.L)^(ss-1))*(Tprimex/Tx)));
	        #print(A)
        	runif.test <- Uvect[i];
    	    if(runif.test<A){
	                T.mat[i,]   <- prop.Tv;              
                	Tmrcav[i]   <- sum(prop.Tv);
                	}else{
           				T.mat[i,]   <- old.Tv
        	        	Tmrcav[i]   <- sum(old.Tv);                       
    	       }
	}
	
	Tmrcav	<-	matrix(Tmrcav,ncol=1)
	return(mcmc(Tmrcav))
	
}


# Function to manipulate the results of the MCMC chain given by MC.coal
# The function uses the autocorrelation function to determine the appropriate lag to samples
# the MCMC chain and return the number of samples required
# ts = a time series product of MH.coal
# samples = the number of samples of the posterior you want to save
# burn.in = The number of samples you want to exclude
# plot.it = If you want to plot the autocorrelation function

MH.coal.stats	<-	function(mcmc.obj,burn.in,plot=FALSE,lag.max,...){
	if(missing(lag.max)){lag.max	<-	50}
	ts			<-	as.ts(mcmc.obj)
	cor.func	<-	acf(ts,lag.max,plot=plot,...)
	lag.ind		<-	which.min(abs(cor.func$acf))
	lag			<-	cor.func$lag[lag.ind,1,1]
	if(missing(burn.in)){burn.in	<-	1}
	thinned.mcmc<-	mcmc(mcmc.obj,start=burn.in,end=length(ts),thin=lag)
	
	return(thinned.mcmc)
	
}



