library(ape)
library(mvtnorm)
library(rjags)
library(snow)
source("MHcoal.R")

error.bar <- function(x,y,upper,lower=upper,length=0.1,type=c("X","Y"),...){
	
	if(length(x) != length(y) | length(y) !=length(lower) | length(lower) != length(upper))
	{stop("vectors must be same length")}
	if(type=="Y"){
		arrows(x,upper, x,lower, angle=90, code=3, length=length, ...)
		}
	else if(type=="X"){
		arrows(upper,y,lower,y, angle=90, code=3, length=length, ...)
	}
}
vioplot2 <-function(x, ..., range = 1.5, h = NULL, ylim = NULL, names = NULL, 
    horizontal = FALSE, col = "magenta", border = "black", lty = 1, 
    lwd = 1, rectCol = "black", colMed = "white", pchMed = 19, 
    at, add = FALSE, wex = 1, drawRect = TRUE) 
{
    datas <- list(x, ...)
    n <- length(datas)
    if (missing(at)) 
        at <- 1:n
    upper <- vector(mode = "numeric", length = n)
    lower <- vector(mode = "numeric", length = n)
    q1 <- vector(mode = "numeric", length = n)
    q3 <- vector(mode = "numeric", length = n)
    med <- vector(mode = "numeric", length = n)
    base <- vector(mode = "list", length = n)
    height <- vector(mode = "list", length = n)
    baserange <- c(Inf, -Inf)
    args <- list(display = "none")
    if (!(is.null(h))) 
        args <- c(args, h = h)
    for (i in 1:n) {
        data <- datas[[i]]
        data.min <- min(data)
        data.max <- max(data)
        q1[i] <- quantile(data, 0.25)
        q3[i] <- quantile(data, 0.75)
        med[i] <- median(data)
        iqd <- q3[i] - q1[i]
        upper[i] <- min(q3[i] + range * iqd, data.max)
        lower[i] <- max(q1[i] - range * iqd, data.min)
        est.xlim <- c(min(lower[i], data.min), max(upper[i], 
            data.max))
        smout <- do.call("sm.density", c(list(data, xlim = est.xlim), 
            args))
        hscale <- 0.4/max(smout$estimate) * wex
        base[[i]] <- smout$eval.points
        height[[i]] <- smout$estimate * hscale
        t <- range(base[[i]])
        baserange[1] <- min(baserange[1], t[1])
        baserange[2] <- max(baserange[2], t[2])
    }
    if (!add) {
        xlim <- if (n == 1) 
            at + c(-0.5, 0.5)
        else range(at) + min(diff(at))/2 * c(-1, 1)
        if (is.null(ylim)) {
            ylim <- baserange
        }
    }
    if (is.null(names)) {
        label <- 1:n
    }
    else {
        label <- names
    }
    boxwidth <- 0.05 * wex
    if (!add) 
        plot.new()
    if (!horizontal) {
        if (!add) {
            plot.window(xlim = xlim, ylim = ylim)
            axis(2)
            axis(1, at = at, label = label)
        }
        #box()
        for (i in 1:n) {
            polygon(c(at[i] - height[[i]], rev(at[i] + height[[i]])), 
                c(base[[i]], rev(base[[i]])), col = col, border = border, 
                lty = lty, lwd = lwd)
            if (drawRect) {
                lines(at[c(i, i)], c(lower[i], upper[i]), lwd = lwd, 
                  lty = lty)
                rect(at[i] - boxwidth/2, q1[i], at[i] + boxwidth/2, 
                  q3[i], col = rectCol)
                points(at[i], med[i], pch = pchMed, col = colMed)
            }
        }
    }
    else {
        if (!add) {
            plot.window(xlim = ylim, ylim = xlim)
            axis(1)
            axis(2, at = at, label = label)
        }
        #box()
        for (i in 1:n) {
            polygon(c(base[[i]], rev(base[[i]])), c(at[i] - height[[i]], 
                rev(at[i] + height[[i]])), col = col, border = border, 
                lty = lty, lwd = lwd)
            if (drawRect) {
                lines(c(lower[i], upper[i]), at[c(i, i)], lwd = lwd, 
                  lty = lty)
                rect(q1[i], at[i] - boxwidth/2, q3[i], at[i] + 
                  boxwidth/2, col = rectCol)
                points(med[i], at[i], pch = pchMed, col = colMed)
            }
        }
    }
    invisible(list(upper = upper, lower = lower, median = med, 
        q1 = q1, q3 = q3))
}
# Code to estimate the TMRCA of the B. anthracis data set for 11 zebras and a lab experiment.

zeb.file	<-	read.delim("~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/ZebraSNR.txt")
zebnum		<-	unique(zeb.file[,2])
zeb.data	<-	matrix(0,ncol=2,nrow=length(zebnum),dimnames=list(zebnum,c("N","N.segreg")))

# Extracting Data
for (i in 1:length(zebnum)){
	zeb1		<-	zeb.file[zeb.file[,2]==zebnum[i],]
	missing.dat	<-	unique(which(zeb1==-9,arr.ind=TRUE)[,1])
	if(length(missing.dat)==0){zeb1	<-	zeb1[,-c(1,2)]}else{
	zeb1	<-	zeb1[-missing.dat,-c(1,2)]}
	nalleles	<-	apply(zeb1,2,function(x)length(unique(x)))
	segreg.sites<-	length(which(nalleles>1))
	n.inds		<-	nrow(zeb1)
	zeb.data[i,]	<-	c(n.inds,segreg.sites)
}

# Estimating TMRCA using Metropolis Hastings algorithm

zeb.mcmc	<-	list()

names(zeb.mcmc) <- rownames(zeb.data)

lag.n		<-	rep(0,nrow(zeb.data))

for(i in 1:nrow(zeb.data)){
	chain		<-	MH.coal(n=zeb.data[i,1],M=1000000,ss=zeb.data[i,2],theta=0.455)
	zeb.mcmc[[i]]<-	chain
}

tmrca.hat	<-	rep(0,nrow(zeb.data))
E.tmrca		<-	rep(0,nrow(zeb.data))
tmrca.lo	<-	rep(0,nrow(zeb.data))
tmrca.up	<-	rep(0,nrow(zeb.data))

for(i in 1:nrow(zeb.data)){
	
	thinned.ch	<-	MH.coal.stats(zeb.mcmc[[i]],plot=TRUE,lag.max=100)
	sum.mcmc	<-	summary(thinned.ch)
	tmrca.hat[i]<-	sum.mcmc$statistics[1]
	tmrca.up[i]	<-	sum.mcmc$quantiles["97.5%"]
	tmrca.lo[i]	<-	sum.mcmc$quantiles["2.5%"]
	E.tmrca[i]	<-	median(thinned.ch[,1])
	
}

zeb.results	<-	cbind(zeb.data,tmrca.lo,tmrca.hat,E.tmrca,tmrca.up)
lab.results	<-	zeb.results[4,]
zeb.results	<-	zeb.results[-4,]

ngens.lab	<-	214
Ne.lab		<-	ngens.lab/(2*lab.results["E.tmrca"])	

mu.hat		<-	0.455/(2*Ne.lab)
Ne.zebs		<-	Ne.lab/2

jm.hat		<-	zeb.results[,"E.tmrca"]*2*Ne.zebs
jm.up		<-	zeb.results[,"tmrca.up"]*2*Ne.zebs
jm.lo		<-	zeb.results[,"tmrca.lo"]*2*Ne.zebs

ngens.pday	<-	ngens.lab/6
num.days	<-	jm.hat/ngens.pday
num.days.up	<-	jm.up/ngens.pday
num.days.lo	<-	jm.lo/ngens.pday

zeb.results.days	<-	cbind(num.days.lo,num.days,num.days.up)



tiff("~/Dropbox/JuanPabloThesis/PostDoc/Results/TMRCA_plot.tiff",width=6,height=6,units="in",res=300,compression="lzw",type="cairo",family="times")
par(mar=c(3,3,1,1),oma=c(0.5,0.5,0.5,0.5),mgp=c(2,0.3,0),tcl=-0.25)
plot(1:length(num.days),num.days,xaxt="n",pch=19,ylim=c(0,12),bty="l",xlab="Zebra No.",ylab="Time to most Recent Common Ancestor (Days)",cex=2)
error.bar(1:length(num.days),num.days,upper=num.days.up,lower=num.days.lo,type="Y",length=0)
axis(1,at=1:length(num.days),labels=names(num.days))
dev.off()

####  Computing Pr(waiting time to gen. diversity is > 4 (and max of XXX) days)

cdfs.mat <- matrix(0,nrow(zeb.results.days), ncol=12)

for(i in 1:nrow(zeb.results.days)){
	
		ith.chain <- zeb.mcmc[[i]]
		transf.chain <- (ith.chain*2*Ne.zebs)/ngens.pday
		
		cdf.vals <- rep(0,12) 
		for(j in 1:12){

			cdf.vals[j] <-sum(transf.chain<j)/length(ith.chain)			
			
		}
		
		cdfs.mat[i,] <- cdf.vals
	
}

rownames(cdfs.mat) <- rownames(zeb.results.days)
colnames(cdfs.mat) <- paste0(rep("Pr(TMRCA<",12),1:12, rep(")",12))



library("MASS")
write.matrix(x=cdfs.mat, file="Pr(TMRCA<x).txt")
save.image(file="TMRCA-allzebs.RData")

#######################################################
# Estimating the time to the most recent common ancestor assuming
# exponential population growth

# The jags model
sink("coalescent_mod.txt")
cat("
	model{


	# Priors
	
	# We need only priors for theta0 and beta
		theta0	~	dunif(0,10)
		beta	~	dunif(0,200)
	
	# Model
	# Loop along Clones

	for(k in 1:K){	
				
		# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
		for(i in 1:(n[k]-1)){ # From past to present
				
			h[i,k]			<-	i+1
			i.ch2[i,k]		<-	(h[i,k]*(h[i,k]-1))/2
			us[i,k]			~	dexp(i.ch2[i,k])
			us.exp[i,k]		<-	(exp(-us[i,k]*beta)-1)/(-beta)
		
			} # end individuals loop
		
		for(i in 1:(n[k]-1)){
				
			br.times[i,k]	<-	sum(us.exp[1:(n[k]-i),k])
			theta.i[i,k]	<-	theta0*exp(-beta*(br.times[i,k]))			
			lambda.i[i,k]	<-	(theta.i[i,k]*us.exp[i,k]*(i+1))/2

		}
			
		tmrca[k]	<-	br.times[1,k]
		lambda[k]	<-	sum(lambda.i[,k])			
		s[k] 		~ 	dpois(lambda[k]) # Number of mutations across the tree

	} # end clones loop
	
}")
sink()

# Estimating the number of clones appropriate for each zebra
# Zebra Number 1

K	<-	c(1,2,4,8,16,32,64,128,256,502)

estimation	<-	function(r){

	n.clons	<-	rep(zeb.data[1,1],K[r])
	s.clons	<-	rep(zeb.data[1,2],K[r])

	data.list	<-	list(n=n.clons,s=s.clons,K=K[r])

	params	<-	c("theta0","beta")

	jm		<-	jags.model(file="coalescent_mod.txt",data=data.list
						,n.chains=2,n.adapt=1000)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=20000,thin=20)
	
	out
	
}

cl	<-	makeCluster(length(K),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("K","zeb.data"))
par.samples	<-	clusterApply(cl,1:length(K),estimation)
stopCluster(cl)

first.eig	<-	rep(0,length(K))
for(i in 1:length(K)){
	ith.k	<-	par.samples[[i]]
	ith.chain<-	rbind(ith.k[[1]],ith.k[[2]])
	first.eig[i]<-eigen(var(ith.chain))$values[1]
}

# With this we identified that the appropriate number of clons to estimate beta and theta is 64
# Now will perform profile likelihood to calculate the confidence intervals.
zeb.1	<-	par.samples[[which(K==64)]]
# Sample 50.000 us form the model given beta.hat and theta0.hat
zeb.1.sum	<-	summary(zeb.1)
beta.hat1	<-	zeb.1.sum$statistics[1,1]
theta0.hat1	<-	zeb.1.sum$statistics[2,1]

sink("coalescent_kalman.txt")
cat("
	model{

	# Model				
	# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
	for(i in 1:(n-1)){ # From past to present
				
		h[i]			<-	i+1
		i.ch2[i]		<-	(h[i]*(h[i]-1))/2
		us[i]			~	dexp(i.ch2[i])
		us.exp[i]		<-	(exp(-us[i]*beta)-1)/(-beta)
	
	} # end individuals loop
		
	for(i in 1:(n-1)){
		
		br.times[i]	<-	sum(us.exp[1:(n-i)])
		theta.i[i]	<-	theta0*exp(-beta*(br.times[i]))			
		lambda.i[i]	<-	(theta.i[i]*us.exp[i]*(i+1))/2			
			
	}
			
	tmrca		<-	br.times[1]
	lambda		<-	sum(lambda.i)			
	s	 		~ 	dpois(lambda) # Number of mutations across the tree
		
}")
sink()

data.list		<-	list(n=29,s=4,beta=beta.hat1,theta0=theta0.hat1)
params			<-	c("us.exp")
exp.kalman.jm	<-	jags.model(file="coalescent_kalman.txt",data=data.list
						,n.chains=1,n.adapt=1000)
exp.kalman.out	<-	coda.samples(model=exp.kalman.jm,variable.names=params,n.iter=50000,thin=1)

theta0.seq	<-	seq(0,10,length=1000)
beta.seq	<-	seq(0,10,length=1000)
rl.theta.i	<-	matrix(0,ncol=1000,nrow=50000)
rl.beta.i	<-	matrix(0,ncol=1000,nrow=50000)

for(i in 1:50000){
	
	ith.us		<-	exp.kalman.out[[1]][i,]
	p.of.th.bh	<-	rep(0,1000)
	p.of.tj.bh	<-	rep(0,1000)
	p.of.th.bj	<-	rep(0,1000)
	
	for(j in 1:1000){
		p.of.th.bh[j]	<-	-Exp.mut.nll(s=4,us=ith.us,theta.0=theta0.hat1,beta=beta.hat1)
		p.of.tj.bh[j]	<-	-Exp.mut.nll(s=4,us=ith.us,theta.0=theta0.seq[j],beta=beta.hat1)
		p.of.th.bj[j]	<-	-Exp.mut.nll(s=4,us=ith.us,theta.0=theta0.hat1,beta=beta.seq[j])
	}
	
	rl.theta.i[i,]	<-	p.of.tj.bh/p.of.th.bh
	rl.beta.i[i,]	<-	p.of.th.bj/p.of.th.bh
	
}















# Running the Jags model
library(snow)

K	<-	20
reps<-	1

estimation	<-	function(r){

	n.clons	<-	matrix(zeb.data[r,1],ncol=K)
	s.clons	<-	matrix(zeb.data[r,2],ncol=K)

	data.list	<-	list(n=n.clons,s=s.clons,reps=reps,K=K)

	params	<-	c("theta0","beta")

	jm		<-	jags.model(file="coalescent_mod.txt",data=data.list
						,n.chains=2,n.adapt=50000)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=100000,thin=100)
	
	out
	
}

cl	<-	makeCluster(nrow(zeb.data),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("K","reps","zeb.data"))
par.samples	<-	clusterApply(cl,1:nrow(zeb.data),estimation)
stopCluster(cl)

names(par.samples)	<-	rownames(zeb.data)

save.image("~/Dropbox/JuanPabloThesis/PostDoc/Results/TMRCA_05_05_2017.RData")

beta.hat		<-	rep(0,nrow(zeb.data))
theta0.hat		<-	rep(0,nrow(zeb.data))
beta.hat.CI		<-	rep(0,nrow(zeb.data))
theta0.hat.CI	<-	rep(0,nrow(zeb.data))

for(i in 1:nrow(zeb.data)){
	
	ith.samp<-	par.samples[[i]]
	ith.sum	<-	summary(par.samples[[i]])
	ith.var	<-	1.96*sqrt(20*var(rbind(ith.samp[[1]][,1:2],ith.samp[[2]][,1:2])))
	
	beta.hat[i]		<-	ith.sum$statistics[1,1]
	beta.hat.CI[i]	<-	diag(ith.var)[1]
	theta0.hat[i]	<-	ith.sum$statistics[2,1]
	theta0.hat.CI[i]	<-	diag(ith.var)[2]	
}

par(mfrow=c(4,3))
for(i in 1:nrow(zeb.data)){
	ith.samp	<-	par.samples[[i]]
	ith.theta	<-	c(ith.samp[[1]][,2],ith.samp[[2]][,2])
	hist(ith.theta)
}

par(mfrow=c(4,3))
for(i in 1:nrow(zeb.data)){
	ith.samp	<-	par.samples[[i]]
	ith.beta	<-	c(ith.samp[[1]][,1],ith.samp[[2]][,1])
	hist(ith.beta)
}

###### Obtaining kalman estimates for TMRCA
sink("coalescent_kalman.txt")
cat("
	model{

	# Model
	# Loop along Clones

	for(k in 1:K){	
		
		# Loop along Zebras
		
		for (j in 1:reps){
		
			# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
			for(i in 1:(n[j,k]-1)){ # From past to present
				
				h[i,j,k]			<-	i+1
				i.ch2[i,j,k]		<-	(h[i,j,k]*(h[i,j,k]-1))/2
				us[i,j,k]			~	dexp(i.ch2[i,j,k])
				us.exp[i,j,k]		<-	(exp(-us[i,j,k]*beta[j])-1)/(-beta[j])
		
			} # end individuals loop
				
			
			
			for(i in 1:(n[j,k]-1)){
				
				br.times[i,j,k]	<-	sum(us.exp[1:(n[j,k]-i),j,k])
				theta.i[i,j,k]	<-	theta0[j]*exp(-beta[j]*(br.times[i,j,k]))			
				lambda.i[i,j,k]	<-	(theta.i[i,j,k]*us.exp[i,j,k]*(i+1))/2

			}
			
			tmrca[j,k]	<-	br.times[1,j,k]
			lambda[j,k]	<-	sum(lambda.i[,j,k])			
			s[j,k] 		~ 	dpois(lambda[j,k]) # Number of mutations across the tree

		} # end replicates loop

	} # end clones loop
	
}")
sink()

K	<-	1
reps<-	1

estimation	<-	function(r){

	n.clons	<-	matrix(zeb.data[r,1],ncol=K)
	s.clons	<-	matrix(zeb.data[r,2],ncol=K)

	data.list	<-	list(n=n.clons,s=s.clons,reps=reps,K=K,beta=beta.hat[r],theta0=theta0.hat[r])

	params	<-	c("tmrca")

	jm		<-	jags.model(file="coalescent_kalman.txt",data=data.list
						,n.chains=1,n.adapt=1)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
	
	out
	
}

cl	<-	makeCluster(nrow(zeb.data),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("K","reps","zeb.data","beta.hat","theta0.hat"))
kalman.samples	<-	clusterApply(cl,1:nrow(zeb.data),estimation)
stopCluster(cl)

names(kalman.samples)	<-	rownames(zeb.data)

tmrca.samples	<-	matrix(NA,nrow=50000,ncol=nrow(zeb.data))

colnames(tmrca.samples)	<-	rownames(zeb.data)

for(i in 1:nrow(zeb.data)){
	ith.zebra			<-	kalman.samples[[i]]
	tmrca.samples[,i]	<-	c(ith.zebra[[1]][,1])
}

lab.results	<-	1.620021 # This comes from estimating TMRCA for lab results assuming constant pop size
zeb.results	<-	tmrca.samples[,-4]

# Estimate mutation rate from lab experiment
ngens.lab		<-	214

theta.wat.exp	<-	2/sum(1/1:45)
Ne.lab			<-	ngens.lab/(2*lab.results)
mut.rate		<-	theta.wat.exp/(2*Ne.lab)

N0.hats			<-	theta0.hat[-4]/(2*mut.rate)


j.transf	<-	function(tmrca,N0,beta){
	
	(1/beta)*log((2*beta*N0*tmrca)+1)
	
}

tmrca.transf	<-	matrix(0,ncol=ncol(zeb.results),nrow=nrow(zeb.results))
beta.hat.zeb	<-	beta.hat[-4]

for(i in 1:ncol(zeb.results)){
	
	tmrca.transf[,i]	<-	j.transf(zeb.results[,i],N0=N0.hats[i],beta=beta.hat.zeb[i])
	
}

tmrca.days	<-	tmrca.transf/6

par(mfrow=c(3,4))
for(i in 1:11){
	
	hist(tmrca.days[,i])
	
}


####  Computing Pr(waiting time to gen. diversity is > 4 (and max of XXX) days)

cdfs.mat <- matrix(0,ncol(tmrca.days), ncol=12)

for(i in 1:ncol(tmrca.days)){
	
		ith.chain 	<-	tmrca.days[,i]
		
		cdf.vals <- rep(0,12) 
		for(j in 1:12){

			cdf.vals[j] <-sum(ith.chain<j)/length(ith.chain)			
			
		}
		
		cdfs.mat[i,] <- cdf.vals
	
}

rownames(cdfs.mat) <- rownames(zeb.data)[-4]
colnames(cdfs.mat) <- paste0(rep("Pr(TMRCA<",12),1:12, rep(")",12))

cdfs.mat

write.table(cdfs.mat,"~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/cdf_exponential.txt",sep="\t")


# Now the Kalman estimates for tmrca for constant population growth

theta.wat	<-	rep(0,11)
zeb.only	<-	zeb.data[-4,]

for(i in 1:11){
	
	theta.wat[i]	<-	zeb.only[i,2]/sum(1/1:zeb.only[i,1])
	
}

# Before continuing I wanted to test estimating theta from the model using data cloning
# instead of using the theta watterson's estimator

sink("coalescent_const.txt")
cat("
	model{
	
	# Prior for theta
	for(j in 1:reps){
		theta[j]	~	dunif(0,2)
	}
	# Model
	# Loop along Clones

	for(k in 1:K){	
		
		# Loop along Zebras
		
		for (j in 1:reps){
		
			# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
			for(i in 1:(n[j,k]-1)){ # From past to present
				
				h[i,j,k]			<-	i+1
				i.ch2[i,j,k]		<-	(h[i,j,k]*(h[i,j,k]-1))/2
				us[i,j,k]			~	dexp(i.ch2[i,j,k])
				sum.us[i,j,k]		<-	us[i,j,k]*h[i,j,k]				
		
			} # end individuals loop
			
			tmrca[j,k]	<-	sum(us[,j,k])
			lambda[j,k]	<-	theta[j]/2*sum(sum.us[,j,k])
					
			s[j,k] 		~ 	dpois(lambda[j,k]) # Number of mutations across the tree

		} # end replicates loop

	} # end clones loop
	
}")
sink()


K	<-	20
reps<-	1

estimation	<-	function(r){

	n.clons	<-	matrix(zeb.only[r,1],ncol=K)
	s.clons	<-	matrix(zeb.only[r,2],ncol=K)

	data.list	<-	list(n=n.clons,s=s.clons,reps=reps,K=K)

	params	<-	c("theta")

	jm		<-	jags.model(file="coalescent_const.txt",data=data.list
						,n.chains=2,n.adapt=10000)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=20)
	
	out
	
}

cl	<-	makeCluster(nrow(zeb.data),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("K","reps","zeb.only"))
const.samples	<-	clusterApply(cl,1:nrow(zeb.only),estimation)
stopCluster(cl)

theta.hat	<-	rep(0,nrow(zeb.only))

for(i in 1:nrow(zeb.only)){
	ith.zebra	<-	const.samples[[i]]
	sum.stats	<-	summary(ith.zebra)
	theta.hat[i]<-	sum.stats$statistics[1]#2/(1+exp(-sum.stats$statistics[1]))
}

cbind(hat=theta.hat,watterson=theta.wat)
            # hat watterson
 # [1,] 1.0729800 1.0096793
 # [2,] 1.1032979 1.0377697
 # [3,] 1.0576918 0.9667407
 # [4,] 0.5305318 0.5139464
 # [5,] 0.5216062 0.5048397
 # [6,] 1.1292663 1.0593338
 # [7,] 0.2752961 0.2709430
 # [8,] 0.5216062 0.5048397
 # [9,] 1.1168443 1.0482295
# [10,] 0.7941931 0.7639087
# [11,] 0.5981862 0.5722284

# They are almost identical so I will now use the estimates from the model to
# obtain the Kalman estimates of the TMRCA using the Constant population size model

sink("coalescent_const_kalman.txt")
cat("
	model{
	

	# Model
	# Loop along Clones

	for(k in 1:K){	
		
		# Loop along Zebras
		
		for (j in 1:reps){
		
			# Loop along Samples (this is the number of tips in the tree) in Zebras		
			
			for(i in 1:(n[j,k]-1)){ # From past to present
				
				h[i,j,k]			<-	i+1
				i.ch2[i,j,k]		<-	(h[i,j,k]*(h[i,j,k]-1))/2
				us[i,j,k]			~	dexp(i.ch2[i,j,k])
				sum.us[i,j,k]		<-	us[i,j,k]*h[i,j,k]				
		
			} # end individuals loop
			
			tmrca[j,k]	<-	sum(us[,j,k])
			lambda[j,k]	<-	theta/2*sum(sum.us[,j,k])
					
			s[j,k] 		~ 	dpois(lambda[j,k]) # Number of mutations across the tree

		} # end replicates loop

	} # end clones loop
	
}")
sink()

K	<-	1
reps<-	1

estimation	<-	function(r){

	n.clons	<-	matrix(zeb.only[r,1],ncol=K)
	s.clons	<-	matrix(zeb.only[r,2],ncol=K)

	data.list	<-	list(n=n.clons,s=s.clons,reps=reps,K=K,theta=theta.hat[r])

	params	<-	c("tmrca")

	jm		<-	jags.model(file="coalescent_const_kalman.txt",data=data.list
						,n.chains=2,n.adapt=5000)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=20000,thin=20)
	
	out
	
}

cl	<-	makeCluster(nrow(zeb.data),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("K","reps","zeb.only","theta.hat"))
const.kalman.samples	<-	clusterApply(cl,1:nrow(zeb.only),estimation)
stopCluster(cl)

names(const.kalman.samples)	<-	rownames(zeb.only)

tmrca.const.samples	<-	matrix(NA,nrow=2000,ncol=nrow(zeb.only))

colnames(tmrca.const.samples)	<-	rownames(zeb.only)

for(i in 1:nrow(zeb.only)){
	ith.zebra			<-	const.kalman.samples[[i]]
	tmrca.const.samples[,i]	<-	c(ith.zebra[[1]][,1],ith.zebra[[2]][,1])
}

tmrca.const.tr	<-	tmrca.const.samples*(Ne.lab)
tmrca.const.days<-	tmrca.const.tr/(214/6)

####  Computing Pr(waiting time to gen. diversity is > 4 (and max of XXX) days)

cdfs.const.mat <- matrix(0,ncol(tmrca.const.days), ncol=12)

for(i in 1:ncol(tmrca.const.days)){
	
		ith.chain 	<-	tmrca.const.days[,i]
		
		cdf.vals <- rep(0,12) 
		for(j in 1:12){

			cdf.vals[j] <-sum(ith.chain<j)/length(ith.chain)			
			
		}
		
		cdfs.const.mat[i,] <- cdf.vals
	
}

rownames(cdfs.const.mat) <- rownames(zeb.data)[-4]
colnames(cdfs.const.mat) <- paste0(rep("Pr(TMRCA<",12),1:12, rep(")",12))

cdfs.const.mat

write.table(cdfs.const.mat,"~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/cdf_const.txt",sep="\t")

# apply(tmrca.const.days,2,median)

# par(mfrow=c(3,4))
# for(i in 1:11){
 	
 	# hist(tmrca.const.days[,i])
 	
# }

# par(mfrow=c(3,4))
# for(i in 1:11){
 	# hist(tmrca.const.days[,i],freq=FALSE,xlim=c(0,16))
 	# hist(tmrca.days[,i],freq=FALSE,xlim=c(0,16),add=TRUE)
# }


# Ploting the histograms of the kalman samples of the TMRCA using a model of Constant population size
# and exponential population growth.
zeb.nums	<-	rownames(zeb.only)
my.breaks	<-	c(0:17)

y.max		<-	c(1.5,1.5,1.5,3.5,3.5,1.5,7.5,3.5,1.5,2,3.5)

tiff("~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/TMRCA_dens.tiff",width=9,height=6.5,units="in"
	,res=300,compression="lzw",type="cairo",family="times")
par(mfrow=c(4,3),mar=c(3,3,0.5,0.5),tcl=-0.25,mgp=c(2,0.5,0),oma=c(2,2,1,1))
for(i in 1:11){
	hist(tmrca.const.days[,i],col="black",main="",xlab="",ylab=""
		,breaks=my.breaks,xaxt="n",yaxp=c(0,round(y.max[i]),2),freq=FALSE,ylim=c(0,y.max[i]),xlim=c(0,13))
	hist(tmrca.days[,i],xlim=c(0,13),col="grey",border="grey",add=TRUE,axes=FALSE,main="",freq=FALSE)
	box(bty="l")
	mtext(paste("Zebra No.",zeb.nums[i],sep=" "),adj=0.75,line=-1,cex=0.75)
	axis(1,at=c(0,3,6,9,12),labels=c(0,3,6,9,expression(""<=12)))
}
plot(0,1,type="n",axes=FALSE,xlab=" ",ylab=" ",xlim=c(0,1),ylim=c(0,1))
legend(0,1,c("Constant\nPopulation Size","Exponential\nPopulation Size")
		,fill=c("black","grey"),border=c("black","grey")
		,bty="n",y.intersp=1.75,cex=1.5)
mtext("Days to Most Recent Common Ancestor",side=1,outer=TRUE)
mtext("Density",side=2,outer=TRUE)
dev.off()

colnames(tmrca.const.days)<-rownames(zeb.only)
colnames(tmrca.days)<-rownames(zeb.only)

write.table(tmrca.const.days,"~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/kalman_tmrca_constant.txt"
			,sep="\t",row.names=FALSE,quote=FALSE)
write.table(tmrca.const.days,"~/Dropbox/JuanPabloThesis/PostDoc/Results/kalman_tmrca_exp.txt"
			,sep="\t",row.names=FALSE,quote=FALSE)
			

# Perform likelihood Ratio test to select the most likely model between the
# constant population size and exponential population growth
# Obtaing Kalman estimates of us under the Exponential growth model

K	<-	1
reps<-	1

estimation	<-	function(r){

	n.clons	<-	matrix(zeb.data[r,1],ncol=K)
	s.clons	<-	matrix(zeb.data[r,2],ncol=K)

	data.list	<-	list(n=n.clons,s=s.clons,reps=reps,K=K,beta=beta.hat[r],theta0=theta0.hat[r])

	params	<-	c("us.exp")

	jm		<-	jags.model(file="coalescent_kalman.txt",data=data.list
						,n.chains=1,n.adapt=1)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
	
	out
	
}

cl	<-	makeCluster(nrow(zeb.data),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("K","reps","zeb.data","beta.hat","theta0.hat"))
us.exp	<-	clusterApply(cl,1:nrow(zeb.data),estimation)
stopCluster(cl)

# Obtain Kalman estimates of us unde the constant growth model
K	<-	1
reps<-	1

estimation	<-	function(r){

	n.clons	<-	matrix(zeb.only[r,1],ncol=K)
	s.clons	<-	matrix(zeb.only[r,2],ncol=K)

	data.list	<-	list(n=n.clons,s=s.clons,reps=reps,K=K,theta=theta.hat[r])

	params	<-	c("us")

	jm		<-	jags.model(file="coalescent_const_kalman.txt",data=data.list
						,n.chains=2,n.adapt=1)

	out		<-	coda.samples(model=jm,variable.names=params,n.iter=50000,thin=1)
	
	out
	
}

cl	<-	makeCluster(nrow(zeb.data),type="SOCK")
clusterEvalQ(cl,library(rjags))
clusterExport(cl,list("K","reps","zeb.only","theta.hat"))
us.const	<-	clusterApply(cl,1:nrow(zeb.only),estimation)
stopCluster(cl)

# The density functions of the constant and Exponential models are written as functions
# in the CoalToolkit2.R source code

n.samps	<-	nrow(us.exp[[1]][[1]])

exp.ll	<-	matrix(0,ncol=nrow(zeb.only),nrow=n.samps)
const.ll<-	matrix(0,ncol=nrow(zeb.only),nrow=n.samps)

for(j in 1:nrow(zeb.only)){
	jth.s		<-	zeb.only[j,2]
	jth.theta0	<-	theta0.hat[j]
	jth.beta	<-	beta.hat[j]
	for(i in 1:n.samps){
		ith.us.exp	<-	us.exp[[1]][[1]][i,]
		#ith.us.const<-	us.const[[1]][[1]][i,]
		ith.exp.ll	<-	-Exp.mut.nll(s=jth.s,us=ith.us.exp,theta.0=jth.theta0,beta=jth.beta)
		exp.ll[i,j]	<-	ith.exp.ll
		ith.const.ll<-	-Const.nll(s=jth.s,us=ith.us.exp,theta=theta.hat[j])	
		const.ll[i,j]<-	ith.const.ll

	}
}

lrt	<-	apply(-2*(const.ll-exp.ll),2,mean)

p.val	<-	1-pchisq(lrt,1)

####### Plotting the model with exponential growth which has a better fit to the data than the
####### constant population model.

tiff("~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/TMRCA_exp_hist.tiff",width=9,height=6.5,units="in"
	,res=300,compression="lzw",type="cairo",family="times")
mat	<-	matrix(c(rep(1:9,each=2),0,10,10,11,11,0),nrow=4,ncol=6,byrow=TRUE)
layout(mat)
par(mar=c(3,3,0.5,0.5),tcl=-0.25,mgp=c(2,0.5,0),oma=c(2,2,1,1))
for(i in 1:11){
	ith.hist<-hist(tmrca.days[,i],col="grey",border="black",main=" ",freq=FALSE,xlab="",ylab=""
					,axes=FALSE)
	y.max	<-	round(max(ith.hist$density),1)
	x.range	<-	range(ith.hist$breaks)
	axis(1,xaxp=c(x.range[1],x.range[2],2))
	axis(2,yaxp=c(0,y.max,2))
	box(bty="l")
	mtext(paste("Zebra No.",zeb.nums[i],sep=" "),adj=0.25,line=-1,cex=0.75)
}
mtext("Days to Most Recent Common Ancestor",side=1,outer=TRUE)
mtext("Density",side=2,outer=TRUE)
dev.off()

# Ploting the results in the same plot as densities

dens.zebs	<-	list()

for(i in 1:11){
	
	dens.zebs[[i]]	<-	density(tmrca.days[,i])
	
}

library(colorRamps)
my.cols		<-	rev(blue2red(5))
mid.quant	<-	apply(tmrca.days,2,quantile,prob=0.5)
my.order	<-	order(fifty.perc)
cat			<-	c(1,rep(2,4),3,4,rep(5,4))
zeb.names	<-	names(mid.quant)
zeb.names	<-	zeb.names[my.order]

zeb.groups	<-	rep(NA,5)
for(i in 1:5){
	
	if(length(cat[cat==i])==1){
		zeb.groups[i]	<-	zeb.names[cat==i]
	}else{zeb.groups[i]	<-	paste(zeb.names[cat==i],collapse=", ")}

}

tiff("~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/TMRCA_exp_dens.tiff",width=5,height=5,units="in"
	,res=300,compression="lzw",type="cairo",family="times")
par(mar=c(3,3,0.5,0.5),oma=rep(0.5,4),mgp=c(2,0.5,0),tcl=-0.25)
plot(0,0,type="n",xlim=c(0,5),ylim=c(0,8),bty="l",xlab="Days to Most Recent Common Ancestor",ylab="Density")
for (i in 1:11){	
	lines(dens.zebs[[my.order[i]]],lwd=2,col=my.cols[cat[i]])
}
legend("topright",legend=zeb.groups,lty=1,lwd=2,bty="n",col=my.cols,title="Zeb No.",title.adj=0)
dev.off()

# Plotting Violin plots
my.seq	<-	c(1:4,6,8,10:13,15)
tiff("~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/TMRCA_exp_violin.tiff",width=5,height=5,units="in"
	,res=300,compression="lzw",type="cairo",family="times")
par(mar=c(3,3,0.5,0.5),oma=rep(0.5,4),mgp=c(2,0.5,0),tcl=-0.25)
plot(0,0,type="n",xlim=c(0,5),ylim=c(0,16),bty="l",xlab="Days to Most Recent Common Ancestor"
	,ylab="Zebra No.",yaxt="n",bty="l")
axis(2,at=my.seq,labels=rev(zeb.names),cex.axis=0.9)
for(i in 1:11){
	vioplot2(tmrca.days[,rev(my.order)[i]],horizontal=TRUE,col=my.cols[rev(cat)[i]],add=TRUE,at=my.seq[i]
			,axes=FALSE)
}
dev.off()

# Calculating Theta 1 from TMRCA, Beta and Theta0

Ne.0	<-	(theta0.hat*Ne.lab)/theta.wat.exp
Ne.1	<-	Ne.0*exp(-(tmrca.samples*beta.hat))
Ne1.bar	<-	apply(Ne.1,2,mean)


theta1	<-	theta0.hat*exp(-(tmrca.samples*beta.hat))
N.1		<-	theta1/(2*mut.rate)
N1.bar	<-	apply(N.1,2,mean)[-4]
N1.CI	<-	apply(N.1,2,quantile,probs=c(0.025,0.975))[,-4]
tmrca.bar<-	apply(tmrca.days,2,mean)
tmrca.CI<-	apply(tmrca.days,2,quantile,probs=c(0.025,0.975))

upper.sd	<-	function(bar,CI){
	
	((CI-bar)/3)+bar
	
}

lower.sd	<-	function(bar,CI){
	
	bar-((bar-CI)/3)
	
}

tmrca.SD<-	matrix(c(lower.sd(bar=tmrca.bar,CI=tmrca.CI[1,]),upper.sd(bar=tmrca.bar,CI=tmrca.CI[2,])),nrow=2,byrow=TRUE)
N1.SD	<-	matrix(c(lower.sd(bar=N1.bar,CI=N1.CI[1,]),upper.sd(bar=N1.bar,CI=N1.CI[2,])),nrow=2,byrow=TRUE)

my.seq	<-	c(1:4,6,8,10:13,15)
tiff("~/Dropbox/JuanPabloThesis/PostDoc/RyanEasterDay/TMRCA_N1_plot.tiff",width=5,height=5,units="in"
	,res=300,compression="lzw",type="cairo",family="times")
par(mar=c(3,3,0.5,0.5),oma=rep(0.5,4),mgp=c(2,0.5,0),tcl=-0.25)
plot(tmrca.bar,N1.bar,ylim=range(N1.SD),xlim=range(tmrca.SD),bty="l",xlab="Days from Infection to Death"
	,ylab="Ne at time of infection",bty="l",pch=19,type="n")
error.bar(tmrca.bar,N1.bar,upper=tmrca.SD[2,],lower=tmrca.SD[1,],type="X",length=0.025)
error.bar(tmrca.bar,N1.bar,upper=N1.SD[2,],lower=N1.SD[1,],type="Y",length=0.025)
points(tmrca.bar,N1.bar,pch=19,cex=1)

dev.off()


