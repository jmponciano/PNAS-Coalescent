#include <Rcpp.h>

namespace loglikdmn {
  double loglikdirmultinom_mesh(std::vector<unsigned> n, std::vector<double> p, double psi);
}

RcppExport SEXP llikdmn(
    SEXP n
    , SEXP p
    , SEXP psi
    ) {

  using namespace Rcpp;
  IntegerVector n_vec(n);
  NumericVector p_vec(p);
  double psi_scalar = as<double>(psi);

  std::vector<unsigned> n_v(n_vec.size());
  std::vector<double> p_v(p_vec.size());
  for(int i = 0; i < n_vec.size(); ++ i) {
    n_v[i] = n_vec[i];
    p_v[i] = p_vec[i];
  }

  return wrap(loglikdmn::loglikdirmultinom_mesh(n_v, p_v, psi_scalar));
}

