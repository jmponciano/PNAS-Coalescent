#' Log-Likelihood Function of a Dirichlet-multinomial Random Variable
#'
#' This function compute the Dirichlet-multinomial log-Likelihood function (Eq. (4) in the paper) without the normalising constant.
#'
#' @param n an nonnegative integer vector with some positive integers, a DMN distributed random vector.
#' @param p a positive number vector, the proportion parameter of DMN.
#' @param psi a non-negative number, the dispersion parameter defined as \eqn{1/A}.
#' @keywords distribution
#' @useDynLib lldmn llikdmn
#' @export
#' @examples
#' p=c(.2, .3, .5)
#' psi=.01
#' n=c(3, 5, 7)
#' lldmn(n, p, psi)
lldmn=function(n, p, psi) .Call(llikdmn, n, p, psi)
