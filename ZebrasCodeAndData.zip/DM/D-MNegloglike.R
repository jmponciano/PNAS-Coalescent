#  Dirichlet-Multinomial likelihood calculations
#
#
library(MCMCpack);
library("MASS");

###-- Simulating counts from a multinomial-dirichlet moel.  'alphas' are Dirichlet parms, 'ntot' is the total number of 
###-- observed individual alleles and 'n' is the number of simulated multinomial samples.
nrep.persite <- function(n,alphas,ntot){
	
	A   <- length(alphas);
	out <- matrix(0,nrow=A,ncol=n);
	for(i in 1:n){
		
		pi.vec <- rdirichlet(n=1,alpha=alphas);
		out[,i]<- rmultinom(n=1,size=ntot,prob=pi.vec);
		
		}
	
	return(out)
}

#> gamma.samp <- rgamma(n= 10000, shape=10, scale= 3)
#> mean(gamma.samp)
#[1] 29.86808
#> 10*3 This is the theoretical mean
#> var(gamma.samp)
#[1] 90.1715
#> 10*9 This is the theoretical variance
# So it works, I have the right gamma

nrep.persite2 <- function(n,alphas,scaleparm,ntot){
	
	A   <- length(alphas);
	out <- matrix(0,nrow=A,ncol=n);
	pi.vec <- rep(0,A)
	for(j in 1:A){pi.vec[j] <- rgamma(n=1,shape=alphas[j], scale=scaleparm);}
	pi.vec <- pi.vec/sum(pi.vec)

	for(i in 1:n){
		out[,i]<- rmultinom(n=1,size=ntot,prob=pi.vec);
	}
	
	return(list(out=out, pi.vec=pi.vec))
}




##----Function to calculate the empirical moments of the allele counts from 'nreps' replicated multinomial-dirichlet 
##----counts for one populations.  These counts are saved in the matrix 'countsmat' of  dimension (A x nreps)
moments.calc <- function(countsmat){
	
	K         <- dim(countsmat)[1];
	nreps     <- dim(countsmat)[2];
	nvec      <- apply(countsmat,2,sum);
	nmat      <- matrix(rep(nvec, each=K), nrow=K,ncol=nreps);
	phats     <- countsmat/nmat;
	
	N         <- sum(nvec);	
	alphas    <- (1/N)*apply(countsmat,1,sum);
	C.mat     <- matrix(0,nrow=K,ncol=nreps);
	
	for(i in 1:K){
		
		alpha.i <- alphas[i];
		for(s in 1:nreps){
			
			C.mat[i,s] <- (1/alpha.i)*nvec[s]*(phats[i,s]-alpha.i)^2
			
			}
		
		} 
	
	C.hat <- (((nreps-1)*(K-1))^(-1))*sum(C.mat);
	g.hat <- (nvec[1]-C.hat)/(C.hat-1)
	
	
	return(list(alphas,C.hat,g.hat))
	
	}


##-- Negative log-likelihood function for S realizations of a K-alleles D-M process:
##-- guess = c(g,a_1,a_2,..,a_K-1), countsmat = [Xvec1,Xvec2,...,XvecS], where 
##-- Xveci = (xi1,xi2,...,xiK)'

DMnegloglike <- function(guess,countsmat){
	
	nvec     <- apply(countsmat,2,sum);
	nreps    <- dim(countsmat)[2];
	K        <- length(guess)
	alphas   <- exp(guess);
	g        <- sum(alphas);

	
	loglikemat <- matrix(0,nrow=nreps,ncol=K);	
	loglikevec <- rep(0,nreps);
	
	for (i in 1:nreps){
		
		ni  <- nvec[i];
		xi  <- countsmat[,i];
		cst <- lgamma(g) - lgamma(ni+g); 
		
		for(k in 1:K){
			
			loglikemat[i,k] <- -lgamma(alphas[k]) + lgamma(alphas[k] + xi[k]);
			}
		
		loglikevec[i] <- cst + sum(loglikemat[i,]);
			
	}
	
	negloglike <- -sum(loglikevec);
	return(negloglike);
	
}

DMnegloglike2 <- function(guess,countsmat){
	
	nvec      <- apply(countsmat,2,sum);
	nreps     <- dim(countsmat)[2];
	K         <- length(guess)
	alphas.km1<- 1/(1+exp(-guess[2:K]));
	g         <- exp(guess[1]);
	sumalphas <- sum(alphas.km1);
	alphas    <- c(alphas.km1, (1-sumalphas));
	if(sumalphas >= 1){negloglike = 10^10}
	
		else{
			loglikemat <- matrix(0,nrow=nreps,ncol=K);			
			loglikevec <- rep(0,nreps)
	
			for (i in 1:nreps){
		
				ni  <- nvec[i];
				xi  <- countsmat[,i];
				cst <- lgamma(g) - lgamma(ni+g);
		
				for(k in 1:K){
			
					loglikemat[i,k] <- -lgamma(g*alphas[k]) + lgamma(g*alphas[k] + xi[k]);				}
		
				loglikevec[i] <- cst + sum(loglikemat[i,]);
			
			}
	
			negloglike <- -sum(loglikevec);
		}
	
	
	return(negloglike);
	
}



DMnegloglike3 <- function(guess,countsmat){
	
	nvec      <- apply(countsmat,2,sum);
	nreps     <- dim(countsmat)[2];
	K         <- length(guess)
	alphas.km1<- 1/(1+exp(-guess[2:K]));
	g         <- exp(guess[1]);
	sumalphas <- sum(alphas.km1);
	alphas    <- c(alphas.km1, (1-sumalphas));
	if(sum(alphas.km1) >= 1){negloglike = 10^20}
	
		else{
			loglikemat <- matrix(0,nrow=nreps,ncol=K);			loglikevec <- rep(0,nreps)
	
			for (i in 1:nreps){
		
				ni  <- nvec[i];
				xi  <- countsmat[,i];
		
				for(k in 1:K){
					
					rvec<- rep(0,xi[k]);
					gvec<- rep(0,ni+1)
									
					for(r in 1:xi[k]){rvec[r] <- log(alphas[k]+(r-1)*(1/g));}
					for(r in 1:(ni+1)){gvec[r] <- log(1+(r-1)*(1/g));}
					loglikemat[i,k] <- sum(rvec) - sum(gvec);				}
		
				loglikevec[i] <- sum(loglikemat[i,]);
			
			}
	
			negloglike <- -sum(loglikevec);
		}
	
	
	return(negloglike);
	
}



####----Main begins: Notation according to Ennis and Bi 1998 

### THREE WAYS OF ESTIMATING THE PARAMETERS

oldalphas   <- c(10,11,10,12,14,16,15,14,13,10,9);
nalleles    <- length(oldalphas);
gtrue       <- sum(oldalphas);
newalphas   <- oldalphas/gtrue;
#DM.sample   <- nrep.persite(n=10,alphas=oldalphas,ntot = 500);
DM.sample   <- nrep.persite2(n=30,alphas=oldalphas,scaleparm=5,ntot =200)
DM.samp     <- DM.sample$out
pis.true    <- DM.sample$pi.vec 

# 0. MOMENT estimates:

mom.hats <- moments.calc(DM.samp)
mom.alphas <- mom.hats[[1]]


# 1. ESTIMATE JUST THE ALPHAS, THEN THE g: This way the newalphas are estimated well, but not the g!!!
guess1 <- c(log(oldalphas));
DMnegloglike(guess1, DM.samp)
best.guess <- optim(par= guess1, fn = DMnegloglike, method = "Nelder-Mead", countsmat=DM.samp);
Min.Negloglike <- best.guess$value
MLEsvec <- exp(best.guess$par)
gmle <- sum(MLEsvec)
newalphas.mles <- MLEsvec;
tots.persp <- apply(DM.samp, 1, sum);
tot.all  <- sum(tots.persp);
pi.hats <- ((newalphas.mles/gmle) + tots.persp)/(gmle + tot.all)

cbind(oldalphas/gtrue,newalphas.mles/gmle, mom.alphas)
cbind(pis.true, pi.hats, tots.persp/tot.all)




## 2. ESTIMATING g, alpha1,alpha2, ..., alphaK-1

guess2 <- c(log(gtrue), log(oldalphas[1:(nalleles-1)]/gtrue)-log(1-(oldalphas[1:(nalleles-1)]/gtrue)));
DMnegloglike2(guess2,DM.sample)
best.guess <- optim(par= guess2, fn = DMnegloglike2, method = "BFGS", countsmat=DM.samp);
Min.Negloglike <- best.guess$value
newalphasmles <- 1/(1+exp(-best.guess$par[2:nalleles]));
gmle <- exp(best.guess$par[1]);
gtrue
newalphas
gmle
newalphasmles


## ESTIMATING g, newalpha1,newalpha2, ..., newalphaK-1

guess3 <- c(log(gtrue), log(oldalphas[1:(nalleles-1)]/gtrue)-log(1-(oldalphas[1:(nalleles-1)]/gtrue)));
DMnegloglike3(guess3,DM.sample)
best.guess <- optim(par= guess3, fn = DMnegloglike3, method = "BFGS", countsmat=DM.sample);
Min.Negloglike <- best.guess$value
newalphasmles <- 1/(1+exp(-best.guess$par[2:nalleles]));
gmle <- exp(best.guess$par[1]);
gtrue
newalphas
gmle
newalphasmles

































