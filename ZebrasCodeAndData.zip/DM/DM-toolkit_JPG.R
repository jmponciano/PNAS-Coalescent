library(MCMCpack);
library("MASS");
nrep.persite <- function(n,alphas,ntot){
	
	A   <- length(alphas);
	out <- matrix(0,nrow=A,ncol=n);
	for(i in 1:n){
		
		pi.vec <- rdirichlet(n=1,alpha=alphas);
		out[,i]<- rmultinom(n=1,size=ntot,prob=pi.vec);
		
		}
	
	return(out)
}

moments.calc <- function(countsmat){
	
	K         <- dim(countsmat)[1];
	nreps     <- dim(countsmat)[2];
	nvec      <- apply(countsmat,2,sum);
	nmat      <- matrix(rep(nvec, each=K), nrow=K,ncol=nreps);
	phats     <- countsmat/nmat;
	
	N         <- sum(nvec);	
	alphas    <- (1/N)*apply(countsmat,1,sum);
	C.mat     <- matrix(0,nrow=K,ncol=nreps);
	
	for(i in 1:K){
		
		alpha.i <- alphas[i];
		for(s in 1:nreps){
			
			C.mat[i,s] <- (1/alpha.i)*nvec[s]*(phats[i,s]-alpha.i)^2
			
			}
		
		} 
	
	C.hat <- (((nreps-1)*(K-1))^(-1))*sum(C.mat);
	if(C.hat<1){C.hat<-1.000001};
	if(C.hat>nvec[1]){C.hat<-nvec[1]}
	g.hat <- (nvec[1]-C.hat)/(C.hat-1);
	
	
	return(list(alphas=alphas,C.hat=C.hat,g.hat=g.hat))
	
	}



DMnegloglike <- function(init.theta=NULL,init.alphas,countsmat){
	
	nvec      <- apply(countsmat,2,sum);
	nreps     <- dim(countsmat)[2];
	K         <- length(guess)
	theta <- init.theta
	if(is.null(theta)){
		hats<-moments.calc(countsmat)
		g<-hats$g.hat
		}
	else{
	g         <- init.theta;}
	alphas    <- init.alphas;
	
			loglikemat <- matrix(0,nrow=nreps,ncol=K);			
			loglikevec <- rep(0,nreps);
	
			for (i in 1:nreps){
		
				ni  <- nvec[i];	
				xi  <- countsmat[,i];
				n.fact<- factorial(ni);
				ni.fact<-sum(factorial(xi))
				cst <- log(n.fact)-log(ni.fact)+lgamma(g) - lgamma(ni+g);
		
				for(k in 1:K){
			
					loglikemat[i,K] <- -lgamma(g*alphas[K]) + lgamma(g*alphas[k] + xi[K]);				}
		
				loglikevec[i] <- cst + sum(loglikemat[i,]);
			
			}
	
			negloglike <- -sum(loglikevec);
	
	return(negloglike);
	
}


	
	
	
