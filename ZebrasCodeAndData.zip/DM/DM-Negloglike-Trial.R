library(vegan)
library(dirmult)
data(BCI)

countsmat <- t(BCI)
source("DMtoolkit.R")
guess.mom<-moments.calc(countsmat)
k=nrow(countsmat)
alphas.mom<-guess.mom[[1]][1:k-1]
guess<-c(log(guess.mom[[3]]),log(alphas.mom)-log(1-alphas.mom))
ml.est<-optim(par=guess,fn=DMnegloglike2,method="Nelder-Mead",countsmat=t(BCI))
ml.ests <- c(exp(ml.est$par[1]), 1/(1+exp(-ml.est$par[2:k])))
alphas.mles<-c(ml.ests[2:k],1-sum(ml.ests[2:k]))
g.mles<-ml.ests[1]
sums<-apply(countsmat,1,sum)
observed<-1/sum(countsmat[,1])*countsmat[,1]
expected<-vector()
for (i in 1:k){
	expected[i]<-(countsmat[,1][i]+g.mles*alphas.mles[i])/(sum(countsmat[,1])+g.mles)
}
par(mfrow=c(2,2))
plot(observed,expected,ylab=expression(paste(E(pi,mu)==frac(n[i]+theta*nu[i],n+theta))),mgp=c(1.5,0.5,0))
abline(a=0,b=1)
data<-cbind(observed,expected)
expected.pi<-vector()
for (i in 1:k){
expected.pi[i]<-(g.mles*alphas.mles[i])/g.mles
}
observed.ind<-countsmat[,1]
expected.ind<-expected.pi*sum(countsmat[,1])
plot(observed,expected.pi,ylab=expression(paste(E(pi)==frac(theta*nu,theta))),mgp=c(1.5,0.5,0))
abline(a=0,b=1)

plot(observed.ind,expected.ind,xlab="Observed No. Individuals",ylab=expression(paste(frac(theta*nu,theta)*n[i])),mgp=c(1.5,0.5,0))
abline(a=0,b=1)

obs.prest<-as.matrix(as.preston(observed.ind))
exp.prest<-as.matrix(as.preston(round(expected.ind)))
barplot(c(obs.prest,0),space=0,ylim=c(0,max(c(obs.prest,exp.prest))),names.arg=c(1,2,4,8,16,32,64),xlab="Octaves",ylab="Species")
lines(0:6+0.5,exp.prest,col="red")

fit<-dirmult(BCI)
simulated<-simPop(100,k,sum(countsmat[,1]),pi=fit$pi,theta=fit$theta)
sim.ind<-apply(simulated$data,2,mean)
sim.prest<-as.matrix(as.preston(round(sim.ind)))
barplot(c(obs.prest,0),space=0,ylim=c(0,max(c(obs.prest,sim.prest))),names.arg=c(1,2,4,8,16,32,64),xlab="Octaves",ylab="Species")
lines(0:6+0.5,sim.prest,col="red")

simulated<-list()
sim<
for (i in 1:100){
	simulated[[i]]<-simulated<-simPop(50,k,apply(countsmat,2,sum),pi=fit$pi,theta=fit$theta)
}
