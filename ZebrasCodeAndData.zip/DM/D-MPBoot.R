#  Dirichlet-Multinomial likelihood Parametric bootstrap
#  
#
library(MCMCpack);
library("MASS");

###-- Simulating counts from a multinomial-dirichlet moDel.  'alphas' are Dirichlet parms, 'ntot' is the total number of 
###-- observed individual alleles and 'n' is the number of simulated multinomial samples.
###-- Below are two functions, one using a 'rdirichlet' function, one using plain composition from gammas
nrep.persite <- function(n,alphas,ntot){
	
	A   <- length(alphas);
	out <- matrix(0,nrow=A,ncol=n);
	for(i in 1:n){
		
		pi.vec <- rdirichlet(n=1,alpha=alphas);
		out[,i]<- rmultinom(n=1,size=ntot,prob=pi.vec);
		
		}
	
	return(out)
}

#> gamma.samp <- rgamma(n= 10000, shape=10, scale= 3)
#> mean(gamma.samp)
#[1] 29.86808
#> 10*3 This is the theoretical mean
#> var(gamma.samp)
#[1] 90.1715
#> 10*9 This is the theoretical variance
# So it works, I have the right gamma pdf

nrep.persite2 <- function(n,alphas,scaleparm,ntot){
	
	A   <- length(alphas);
	out <- matrix(0,nrow=A,ncol=n);
	for(i in 1:n){
		
		pi.vec <- rep(0,A)
		for(j in 1:A){pi.vec[j] <- rgamma(n=1,shape=alphas[j], scale=scaleparm);}
		pi.vec <- pi.vec/sum(pi.vec)
		#pi.vec <- rdirichlet(n=1,alpha=alphas);
		out[,i]<- rmultinom(n=1,size=ntot,prob=pi.vec);
		
		}
	
	return(out)
}




##----Function to calculate the moment estimates of the allele relative frequencies from 'nreps' replicated multinomial-dirichlet 
##----counts for one populations.  These counts are saved in the matrix 'countsmat' of  dimension (A x nreps)
moments.calc <- function(countsmat){
	
	K         <- dim(countsmat)[1];
	nreps     <- dim(countsmat)[2];
	nvec      <- apply(countsmat,2,sum);
	nmat      <- matrix(rep(nvec, each=K), nrow=K,ncol=nreps);
	phats     <- countsmat/nmat;
	
	N         <- sum(nvec);	
	alphas    <- (1/N)*apply(countsmat,1,sum);
	C.mat     <- matrix(0,nrow=K,ncol=nreps);
	
	for(i in 1:K){
		
		alpha.i <- alphas[i];
		for(s in 1:nreps){
			
			C.mat[i,s] <- (1/alpha.i)*nvec[s]*(phats[i,s]-alpha.i)^2
			
			}
		
		} 
	
	C.hat <- (((nreps-1)*(K-1))^(-1))*sum(C.mat);
	if(C.hat<1){C.hat<-1.000001};
	if(C.hat>nvec[1]){C.hat<-nvec[1]}
	g.hat <- (nvec[1]-C.hat)/(C.hat-1);
	
	
	return(list(alphas,C.hat,g.hat))
	
	}


##-- Negative log-likelihood function for S realizations of a K-alleles D-M process:
##-- guess = c(g,a_1,a_2,..,a_K-1), countsmat = [Xvec1,Xvec2,...,XvecS], where 
##-- Xveci = (xi1,xi2,...,xiK)'

DMnegloglike2 <- function(guess,countsmat){
	
	nvec      <- apply(countsmat,2,sum);
	nreps     <- dim(countsmat)[2];
	K         <- length(guess)
	alphas.km1<- 1/(1+exp(-guess[2:K]));
	g         <- exp(guess[1]);
	sumalphas <- sum(alphas.km1);
	alphas    <- c(alphas.km1, (1-sumalphas));
	if(sumalphas >= 1){negloglike <- .Machine$double.xmax}
	
		else{
			loglikemat <- matrix(0,nrow=nreps,ncol=K);			loglikevec <- rep(0,nreps)
	
			for (i in 1:nreps){
		
				ni  <- nvec[i];
				xi  <- countsmat[,i];
				cst <- lgamma(g) - lgamma(ni+g);
		
				for(k in 1:K){
			
					loglikemat[i,k] <- -lgamma(g*alphas[k]) + lgamma(g*alphas[k] + xi[k]);				}
		
				loglikevec[i] <- cst + sum(loglikemat[i,]);
			
			}
	
			negloglike <- -sum(loglikevec);
		}
	
	
	return(negloglike);
	
}


####----Main begins: Notation according to Ennis and Bi 1998 

### Two ways of parameter estimation: ML and Moments

oldalphas   <- c(10,11,10,12,14,16,15,14,13,10,9);
nalleles    <- length(oldalphas);
gtrue       <- sum(oldalphas);
newalphas   <- oldalphas/gtrue;
nreps       <- 10; # NUMBER OF SUBPOPULATIONS IN CLUSTER
npersite    <- 200;# NUMBER OF INDIVIDUALS SAMPLED IN CLUSTER

B <- 1000;

mlesmat    <- matrix(0,nrow=B,ncol=(nalleles+1));
momentsmat <- mlesmat;
simdata    <- array(0,dim=c(nalleles,nreps,B));


for(b in 1:B){
	

	DM.sample   <- nrep.persite2(n=nreps,alphas=oldalphas,scaleparm=5,ntot = npersite)
	simdata[,,b] <- DM.sample;
   #DM.sample <- simdata[,,b] 
	
	# 1. MOMENT estimates:
	moments  <- moments.calc(DM.sample);
	g.moment <- moments[[3]];
	alphas.m <- moments[[1]];
	
	momentsmat[b,] <- c(g.moment,alphas.m);

	# 2. ESTIMATING g, alpha1,alpha2, ..., alphaK-1

	#guess2 <- c(log(g.moment), log(alphas.m[1:(nalleles-1)])-log(1-(alphas.m[1:(nalleles-1)])));
	guess2 <- c(log(gtrue), log(oldalphas[1:(nalleles-1)]/gtrue)-log(1-(oldalphas[1:(nalleles-1)]/gtrue)));
	#DMnegloglike2(guess2,DM.sample)
	best.guess <- optim(par= guess2, fn = DMnegloglike2, method = "BFGS", countsmat=DM.sample);
	Min.Negloglike <- best.guess$value
	newalphasmles <- 1/(1+exp(-best.guess$par[2:nalleles]));
	gmle <- exp(best.guess$par[1]);
	mlesmat[b,] <- c(gmle,newalphasmles, 1-sum(newalphasmles));

}

# Un-comment to save simulated data sets!!
# CHANGE THE PATH: IN WINDOWS IT SHOULD BE "C:...."
#save("mlesmat",file="Documents/CIMATOLD/Research/MarkTaper/Kalinowski/pythonfiles/mlesmat200x10.txt")
#save("momentsmat", file="Documents/CIMATOLD/Research/MarkTaper/Kalinowski/pythonfiles/momentsmat200x10.txt")


# Mean bias for the true proportions:
Bias.MLalphas  <- apply(mlesmat[,2:(nalleles+1)],2,mean) - newalphas;
Bias.MOMalphas <- apply(momentsmat[,2:(nalleles+1)],2,mean) - newalphas;

Bias.alphas <- rbind(Bias.MLalphas,Bias.MOMalphas);
colnames(Bias.alphas) <- c("alpha1","alpha2","alpha3","alpha4","alpha5","alpha6","alpha7","alpha8","alpha9","alpha10","alpha11")
rownames(Bias.alphas) <- c("ML", "Moments")
print(Bias.alphas)

# Table of comparisons for g hat:
mean.gmle    <- mean(mlesmat[,1]);
median.gmle  <- median(mlesmat[,1]);
var.gmle     <- var(mlesmat[,1]);
gML.meanbias <- mean.gmle-gtrue;
gML.medbias  <- median.gmle-gtrue;
gML.MSE      <- var.gmle + gML.meanbias^2;
gMLpctiles   <- quantile(mlesmat[,1],probs=c(0.025,0.725));


mean.gmom    <- mean(momentsmat[,1]);
median.gmom  <- median(momentsmat[,1]); 
var.gmom     <- var(momentsmat[,1]);
gMom.meanbias<- mean.gmom-gtrue;
gMom.medbias <- median.gmom-gtrue;
gMom.MSE     <- var.gmom + gMom.meanbias^2;
gMOMpctiles  <- quantile(momentsmat[,1],probs=c(0.025,0.725));

gML.stats  <- c(as.integer(B),gtrue,mean.gmle,median.gmle,sqrt(var.gmle),gML.meanbias,gML.medbias,gML.MSE,gMLpctiles)
gMom.stats <- c(as.integer(B),gtrue,mean.gmom,median.gmom,sqrt(var.gmom),gMom.meanbias,gMom.medbias,gMom.MSE,gMOMpctiles)
gstats.names <- c("# Boot. replicates","True g","Mean","Median","Std. dev.","Mean bias", "Median bias", "MSE", "2.5 %", "97.5 %");

Stats.mat <- cbind(gML.stats, gMom.stats);
rownames(Stats.mat) <- gstats.names;
print(Stats.mat)

 



# THIS IS THE VERY FIRST RUN:
#par(mfrow=c(1,2))
#hist(mlesmat[,1],main="ML estimate of g", xlim=c(90,200000)); abline(v=gtrue);
#hist(momentsmat[,1],main="Moment estimate of g", xlim=c(90,200000));abline(v=gtrue);

# gtrue = 134, alphas = 0.07462687 0.08208955 0.07462687 0.08955224 0.10447761 0.11940299 0.11194030 0.10447761 0.09701493 0.07462687 0.06716418 
# nreps = 4, npersite = 150
#> summary(mlesmat[,1])
#     Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
#5.885e+01 1.746e+02 2.701e+02 3.016e+04 4.940e+02 3.520e+06 
#> summary(momentsmat[,1])
#    Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
#-14160.0    102.0    141.1    219.4    202.1  66040.0 



























