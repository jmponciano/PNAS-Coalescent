

##### Multinomial fitting #####
pi.hat<-rowSums(BCI)/sum(BCI)
expected<-pi.hat*BCI[,1]
observed<-BCI[,1]
plot(observed,expected,pch=19)
abline(a=0,b=1,col="grey",lty=2)


pi<-rnorm(100,mean=14,sd=4)
simulated<-simPop(J=15,K=100,n=200,pi=pi,theta=0.003)
mom<-moments.calc(t(simulated$data))

optim<-dirmult(simulated$data)

par(mfrow=c(2,2))
plot(simulated$pi,optim$pi,pch=19,main="Numerical Optimization",xlab=expression(paste("True"," ",nu)),ylab=expression(paste("Estimated"," ",nu)))
abline(a=0,b=1,col="grey",lty=2)
plot(simulated$pi,mom$nu,pch=19,main="Moments Estimate",xlab=expression(paste("True"," ",nu)),ylab=expression(paste("Estimated"," ",nu)))
abline(a=0,b=1,col="grey",lty=2)
plot(optim$pi,mom$nu,pch=19,xlab = expression(paste("FSA estimated"," ",nu)),ylab=expression(paste("Moments estimated"," ",nu)),main="Numerical Optimization vs. Moments Estimation")
abline(a=0,b=1,col="grey",lty=2)

#### Comparing three Models using 50 ha BCI counts ####
#### Model 1 is a Zero Sum Multinomial model
#### Model 2 is a Dirichlet Multinomial model
#### Model 3 is a fully parameterized Multinomial model

library(dirmult)
library(vegan)
library(untb)
data(BCI)
DM<-dirmult(BCI)
BCI.counts<-colSums(BCI)
BCI.counts<-count(BCI.counts)
theta.hat<-DM$theta
pi.hat<-DM$pi
DMloglik<-DM$loglik
AIC.DM<-2*224-2*DMloglik
Mnegloglik<-Mnegloglike(prob=colSums(BCI)/sum(BCI),t(BCI))
AIC.M<-2*224-2*(-Mnegloglik)
theta.hat.zsm<-optimal.theta(BCI.counts)
ZSMnegloglik<- theta.likelihood(theta=theta.hat.zsm,x=BCI.counts)
AIC.ZSM<-2*1-2*(ZSMnegloglik)

setwd("~/Desktop/Dirichlet Multinomial")
tiff("Figure1.tiff",width=30,height=15,units="cm",res=300,compression="lzw",type="cairo")
par(mfrow=c(1,3))
plot(BCI.counts,uncertainty=T,main="Zero-sum Multinomial Model")
text(175,1000,paste("AIC = ",round(AIC.ZSM,digits=2)))
plot(BCI.counts,main="Dirichlet Multinomial Model")
text(175,1000,paste("AIC = ",round(AIC.DM,digits=2)))
for (i in 1:10){
	sim<-simPop(J=50,K=225,n=430,pi=pi.hat,theta=theta.hat)
	sums<-sort(colSums(sim$data),decreasing=T)
	points(sums,col="grey",type="l")
}
plot(BCI.counts,main="Full Multinomial model")
text(175,1000,paste("AIC = ",round(AIC.M,digits=2)))
for (i in 1:10){
	sim<-rmultinom(n=50,size=430,prob=BCI.counts/sum(BCI.counts))
	sums<-sort(rowSums(sim),decreasing=T)
	points(sums,col="grey",type="l")
}
legend("bottomleft",legend=c("Observed Abundance","Simulated Abundance"),col=c("red","grey"),lty=c(0,1),pch=c(19,-1),bty="n")
dev.off()

#### Simulation of two sets of data with different parameters reflecting alternative mechanisms ####
pi.1	<-	rnorm(150,mean=10,sd=2)
pi.1	<-	pi.1/sum(pi.1)
pi.2	<-	rnorm(150,mean=30,sd=3)
pi.2	<-	pi.2/sum(pi.2)
theta.1	<-	0.03
theta.2	<-	0.003

group1<-simPop(J=180,K=150,n=23,pi=pi.1,theta=theta.1)$data
group2<-simPop(J=180,K=150,n=20,pi=pi.2,theta=theta.2)$data


#### Hypothesis testing:  
#### H1: Both sets have the same set of parameters
#### H2: Each set has different parameters
#### H3: Each site has its own set of parameters
#### H1 ####

sitemat<-rbind(group1,group2)

optim.par	<-	dirmult(sitemat)
h1.loglik	<-	optim.par$loglik
h1.theta	<-	optim.par$theta
alphas		<-	optim.par$gamma


#### H2 #####


optim.par1	<-	dirmult(group1)
optim.par2	<-	dirmult(group2)
h2.loglik	<-	optim.par1$loglik+optim.par2$loglik
h2.theta	<-	c(optim.par1$theta,optim.par2$theta)
alphas1		<-	optim.par1$gamma
alphas2		<-	optim.par2$gamma
pi1			<-	optim.par1$pi
pi2			<-	optim.par2$pi

#### H3 #####
loglike.vec	<-	rep(0,12)
alphas.ls	<-	list()
theta.vec	<-	rep(0,12)
selection	<-	seq(1,360,by=30)
data		<-	list()

for (i in 1:12){
	start	<-	selection[i]
	end		<-	selection[i]+29
	data[[i]]	<-	sitemat[start:end,]
	optim.par3 <- dirmult(data[[i]])
	theta.vec[i]<-optim.par3$theta
	alphas.ls[[i]]<-optim.par3$gamma
	loglike.vec[i] <- optim.par3$loglik
	
}

h3.loglik<-sum(loglike.vec)

AIC.h1	<-	2*149-2*h1.loglik
AIC.h2	<-	2*298 - 2*h2.loglik
AIC.h3	<-	2*1788 - 2*h3.loglik

tiff("Figure2.tiff",width=30,height=30,units="cm",res=300,compression="lzw",type="cairo")
par(mfrow=c(2,2))
simulated.mat<-matrix(0,ncol=150,nrow=100)
for (i in 1:100){
simulated<-simPop(J=30,K=150,n=23,pi=pi1,theta=h2.theta[1])
simulated.mat[i,]<-colSums(simulated$data)
}
site1	<-	colSums(data[[1]])
exp.sim<- 	apply(simulated.mat,2,mean)
exp.c	<-	count(round(exp.sim))
site1.c	<-	count(site1)
prest.site1	<-	preston(site1.c)
prest.exp1	<-	preston(exp.c)
prest.exp1	<- 	c(0,8,68,72,2,0)
plot(prest.site1,space=0,ylim=c(0,80),ylab="Number of Species",xlab="Individulas per Species",main="Expected under Simulations")
points(0.5:5.5,prest.exp1,type="b",pch=19)
mtext("Site in Group 1",adj=0)

tot.ind <-	sum(site1)
exp.sim<- 	tot.ind*pi1
exp.c	<-	count(round(exp.sim))
prest.exp1	<-	preston(exp.c)
prest.exp1	<- 	c(0,5,68,75,2,0)
plot(prest.site1,space=0,ylim=c(0,80),ylab="Number of Species",xlab="Individulas per Species",main="Expected value of the DM Model")
points(0.5:5.5,prest.exp1,type="b",pch=19)


simulated.mat<-matrix(0,ncol=150,nrow=100)
for (i in 1:100){
simulated<-simPop(J=30,K=150,n=23,pi=pi2,theta=h2.theta[2])
simulated.mat[i,]<-colSums(simulated$data)
}
site7<-colSums(data[[7]])
exp.sim<- 	apply(simulated.mat,2,mean)
exp.c	<-	count(round(exp.sim))
site7.c	<-	count(site7)
prest.site7	<-	preston(site7.c)
prest.exp7	<-	preston(exp.c)
prest.exp7	<-	c(0,1,71,78,0)	
plot(prest.site7,space=0,ylim=c(0,80),ylab="Number of Species",xlab="Individulas per Species")
points(0.5:4.5,prest.exp7,type="b",pch=19)
mtext("Site in Group 2",adj=0)

tot.ind <-	sum(site7)
exp.sim<- 	tot.ind*pi2
exp.c	<-	count(round(exp.sim))
prest.exp7	<-	preston(exp.c)
prest.exp7	<- 	c(0,2,107,41,0,0)
plot(prest.site7,space=0,ylim=c(0,110),ylab="Number of Species",xlab="Individulas per Species")
points(0.5:5.5,prest.exp7,type="b",pch=19)
dev.off()

tiff("Figure3.tiff",width=30,height=20,units="cm",res=300,compression="lzw",type="cairo")
par(mfrow=c(1,2))
plot(sort(log(site1),decreasing=T),pch=19,col="red",ylab="Log Abundance",xlab="Species Ranking in Abundance")
for (i in 1:10){
simulated<-simPop(J=30,K=150,n=23,pi=pi1,theta=h2.theta[1])
sim<-colSums(simulated$data)	
points(sort(log(sim),decreasing=T),type="l",col="grey")}
mtext("Site in Group 1",adj=0)

plot(sort(log(site7),decreasing=T),pch=19,col="red",ylab="Log Abundance",xlab="Species Ranking in Abundance")
for (i in 1:10){
simulated<-simPop(J=30,K=150,n=23,pi=pi2,theta=h2.theta[2])
sim<-colSums(simulated$data)	
points(sort(log(sim),decreasing=T),type="l",col="grey")}
mtext("Site in Group 2",adj=0)

legend("bottomleft",legend=c("Observed Counts","Simulated Counts"),col=c("red","grey"),pch=c(19,-1),lty=c(-1,1))
dev.off()