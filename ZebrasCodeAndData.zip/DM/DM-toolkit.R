#  Dirichlet-Multinomial likelihood Parametric bootstrap
#  
#
library(MCMCpack);
library("MASS");




###-- Simulating counts from a multinomial-dirichlet moDel.  'alphas' are Dirichlet parms, 'ntot' is the total number of 
###-- observed individual alleles and 'n' is the number of simulated multinomial samples.
###-- Below are two functions, one using a 'rdirichlet' function, one using plain composition from gammas
nrep.persite <- function(n,alphas,ntot){
	
	A   <- length(alphas);
	out <- matrix(0,nrow=A,ncol=n);
	for(i in 1:n){
		
		pi.vec <- rdirichlet(n=1,alpha=alphas);
		out[,i]<- rmultinom(n=1,size=ntot,prob=pi.vec);
		
		}
	
	return(out)
}

#> gamma.samp <- rgamma(n= 10000, shape=10, scale= 3)
#> mean(gamma.samp)
#[1] 29.86808
#> 10*3 This is the theoretical mean
#> var(gamma.samp)
#[1] 90.1715
#> 10*9 This is the theoretical variance
# So it works, I have the right gamma pdf

nrep.persite2 <- function(n,alphas,scaleparm,ntot){
	
	A   <- length(alphas);
	out <- matrix(0,nrow=A,ncol=n);
	for(i in 1:n){
		
		pi.vec <- rep(0,A)
		for(j in 1:A){pi.vec[j] <- rgamma(n=1,shape=alphas[j], scale=scaleparm);}
		pi.vec <- pi.vec/sum(pi.vec)
		#pi.vec <- rdirichlet(n=1,alpha=alphas);
		out[,i]<- rmultinom(n=1,size=ntot,prob=pi.vec);
		
		}
	
	return(out)
}




##----Function to calculate the moment estimates of the allele relative frequencies from 'nreps' replicated multinomial-dirichlet 
##----counts for one populations.  These counts are saved in the matrix 'countsmat' of  dimension (A x nreps)
moments.calc <- function(countsmat){
	
	K         <- dim(countsmat)[1];
	nreps     <- dim(countsmat)[2];
	nvec      <- apply(countsmat,2,sum);
	nmat      <- matrix(rep(nvec, each=K), nrow=K,ncol=nreps);
	phats     <- countsmat/nmat;
	
	N         <- sum(nvec);	
	alphas    <- (1/N)*apply(countsmat,1,sum);
	C.mat     <- matrix(0,nrow=K,ncol=nreps);
	
	for(i in 1:K){
		
		alpha.i <- alphas[i];
		for(s in 1:nreps){
			
			C.mat[i,s] <- (1/alpha.i)*nvec[s]*(phats[i,s]-alpha.i)^2
			
			}
		
		} 
	
	C.hat <- (((nreps-1)*(K-1))^(-1))*sum(C.mat);
	if(C.hat<1){C.hat<-1.000001};
	if(C.hat>nvec[1]){C.hat<-nvec[1]}
	g.hat <- (nvec[1]-C.hat)/(C.hat-1);
	
	
	return(list(alphas,C.hat,g.hat))
	
	}


##-- Negative log-likelihood function for S realizations of a K-alleles D-M process:
##-- guess = c(g,a_1,a_2,..,a_K-1), countsmat = [Xvec1,Xvec2,...,XvecS], where 
##-- Xveci = (xi1,xi2,...,xiK)'

DMnegloglike2 <- function(guess,countsmat){
	
	nvec      <- apply(countsmat,2,sum);
	nreps     <- dim(countsmat)[2];
	K         <- length(guess)
	alphas.km1<- 1/(1+exp(-guess[2:K]));
	g         <- exp(guess[1]);
	sumalphas <- sum(alphas.km1);
	alphas    <- c(alphas.km1, (1-sumalphas));
	if(sumalphas >= 1){negloglike <- .Machine$double.xmax}
	
		else{
			loglikemat <- matrix(0,nrow=nreps,ncol=K);			
			loglikevec <- rep(0,nreps)
	
			for (i in 1:nreps){
		
				ni  <- nvec[i];
				xi  <- countsmat[,i];
				cst <- lgamma(g) - lgamma(ni+g);
		
				for(k in 1:K){
			
					loglikemat[i,k] <- -lgamma(g*alphas[k]) + lgamma(g*alphas[k] + xi[k]);				}
		
				loglikevec[i] <- cst + sum(loglikemat[i,]);
			
			}
	
			negloglike <- -sum(loglikevec);
		}
	
	
	return(negloglike);
	
}

