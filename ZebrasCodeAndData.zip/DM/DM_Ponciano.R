library(MCMCpack);
library("MASS");
library(dirmult);
DM.sim <- function(n,nu,ntot){
	
	A   <- length(nu);
	out <- matrix(0,nrow=A,ncol=n);
	for(i in 1:n){
		
		pi.vec <- rdirichlet(n=1,alpha=nu);
		out[,i]<- rmultinom(n=1,size=ntot,prob=pi.vec);
		
		}
	
	return(out)
}

moments.calc <- function(countsmat){
	
	countsmat <- countsmat[rowSums(countsmat)!=0,colSums(countsmat)!=0]
	K         <- dim(countsmat)[1];
	nreps     <- dim(countsmat)[2];
	nvec      <- apply(countsmat,2,sum);
	nmat      <- matrix(rep(nvec, each=K), nrow=K,ncol=nreps);
	phats     <- countsmat/nmat;
	
	N         <- sum(nvec);	
	alphas    <- (1/N)*apply(countsmat,1,sum);
	C.mat     <- matrix(0,nrow=K,ncol=nreps);
	
	for(i in 1:K){
		
		alpha.i <- alphas[i];
		for(s in 1:nreps){
			
			C.mat[i,s] <- (1/alpha.i)*nvec[s]*(phats[i,s]-alpha.i)^2
			
			}
		
		} 
	
	C.hat <- (((nreps-1)*(K-1))^(-1))*sum(C.mat);
	if(C.hat<1){C.hat<-1.000001};
	if(C.hat>nvec[1]){C.hat<-nvec[1]}
	g.hat <- (nvec[1]-C.hat)/(C.hat-1);
	
	
	return(list(nu=alphas,C.hat=C.hat,g.hat=g.hat))
	
	}
	

DMnegloglike<-function(countsmat,alphas){
	
	theta 	  <- sum(alphas)
	nvec      <- apply(countsmat,2,sum);
	nreps     <- ncol(countsmat);
	K         <- length(alphas);
	
		loglikemat <- matrix(0,nrow=nreps,ncol=K);			
		loglikevec <- rep(0,nreps);

	for (i in 1:nreps){
			xi<-countsmat[,i]	
			cst<-(lgamma(theta)-lgamma(nvec[i]+theta))
			
		for (j in 1:K){
			loglikemat[i,j] <- lgamma(alphas[j]+xi[j])-lgamma(alphas[j])
			
		}
		loglikevec[i] <- cst + sum(loglikemat[i,])
	}
	negloglike<-  -sum(loglikevec)
	return(negloglike)
	
}


DM.boot<-function(countsmat,alphas,theta,rep) {
	
	alphas.hat<-alphas
	theta.hat<-theta
	nu.hat<-alphas/theta
	alphas.mat<-matrix(0,nrow=rep,ncol=ncol(countsmat))
	loglike<-rep(0,rep)
	ind <- apply(countsmat,1,sum)
	n <- round(mean(ind))
	
	for(i in 1:rep){
	simulated<-simPop(J=nrow(countsmat),K=ncol(countsmat),n=n,pi=nu.hat,theta=theta.hat)
	sim.fit<-dirmult(simulated$data)
	alphas.mat[i,]<-sim.fit$gamma
	loglike[i]<-sim.fit$loglik
	
	}
	results<-list(loglike,alphas.mat)
	return(results)
}




Mnegloglike<-function(prob,countsmat){
	nrep <- ncol(countsmat)
	loglikevec<-rep(0,nrep)
	for (i in 1:nrep){
		xi<-countsmat[,i]
		loglikevec[i]<-dmultinom(xi,prob=prob,log=T)
	}
	negloglike<- -sum(loglikevec)
	return(negloglike)
}



# .libPaths()
# [1] "/Library/Frameworks/R.framework/Versions/3.3/Resources/library"



